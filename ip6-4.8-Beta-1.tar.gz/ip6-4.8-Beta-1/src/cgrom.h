/*
	MAKE  cgrom
	name is cgrom.h
*/
#include "types.h"
int make_extkanjirom(byte *mem);

// ******************************************************
//   Build.h       iP6 Plus build number
//            by Windy
// *******************************************************

#define PROGRAM_NAME "iP6 Plus "
#define BUILD_NO     "Rel.4.8 Alpha-32"
#define BUILD_DATE   "(Build 2012/02/17"

#define AUTHOR       "Modified by Windy"
#define HOMEPAGE_URL "http://www.eonet.ne.jp/~windy/"
#define HELP_FILE    "HELP-4.7.html"



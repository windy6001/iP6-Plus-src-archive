/** iP6: PC-6000/6600 series emualtor ************************/
/**                                                         **/
/**                           Win32gui.h                    **/
/** modified by Windy 2002-2004                             **/
/** This code is based on ISHIOKA Hiroshi 1998-2000         **/
/** This code is based on fMSX written by Marat Fayzullin   **/
/*************************************************************/
// Win32 ��GUI����ł��B

void savemenu(void);
int hidemenu(void);
int restoremenu(void);

int setMenuCheck(int type ,int sw);

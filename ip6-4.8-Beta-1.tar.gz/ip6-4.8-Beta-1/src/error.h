/** iP6: PC-6000/6600 series emualtor ************************/
/**                                                         **/
/**                           error.h                       **/
/** by Windy 2002-2003                                      **/
/*************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
//#define PRINTDEBUG	debug_printf		//DEBUG PRINT
int debug_printf( char *fmt ,...);

#ifdef __cplusplus
}
#endif


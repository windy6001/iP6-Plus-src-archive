#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

extern int Verbose;
//#include "../P6.h"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "../Sound.h"
#include "../SThread.h"
#include "../os.h"

#ifdef __APPLE__
#include "coreaudio.h"
#endif

#if HAVE_LINUX_SOUNDCARD_H
#include <linux/soundcard.h>
#define  USE_OSSSOUND
#endif
#if HAVE_MACHINE_SOUNDCARD_H
#include <machine/soundcard.h>
#endif

pid_t soundchildpid=0;
int soundpipe[2];
extern int sounddev;


int SoundMainLoop( void *arg);

int SoundMainThreadRun;				// TRUE: thread run
SThread *SoundMainThread;			// thread object

extern struct sysdep_dsp_struct *dsp; // scope is sound only


int unix_soundOpen(void )
{

//  if(!UseSound) {printf("Sound disabled \n"); return;}

  if(Verbose) puts("Starting sound server:");

  //UseSound=0;sounddev=-1;soundchildpid=0;


  if(Verbose) printf("Sound Thread Starting...");
  SoundMainThreadRun = 1;
  SoundMainThread = OSD_CreateThread( SoundMainLoop ,NULL);
  if( SoundMainThread ==NULL)
     {
	  if(Verbose) printf("FAILED\n");
	  return 0;
	 }
  if(Verbose) printf("OK\n");

  UseSound=1;return(1);
}



void unix_soundClose(void)
{
  int J;

#ifdef USE_OSSSOUND
	//osssound_close();
#endif
 SoundMainThreadRun= 0;		// abort thread
 
 OSD_Delay(100);
}



int SoundMainLoop( void *arg)
{
 // short soundbuf2[SOUND_BUFSIZE];
 

 while( SoundMainThreadRun )
   {
	//ym2203_makewave( soundbuf2 ,sizeof(soundbuf2));	// ym2203 makewave
	SoundUpdate();
	OSD_Delay(16*4);



#ifdef USE_OSSSOUND
//        write( sounddev, soundbuf+p, sizeof(soundbuf)/2-p /*SOUND_BUFSIZE*/ );
#endif


#if 0
    {
     FILE *fp;
     fp=fopen("test.dat","a+");
     if( fp) 
        {
         if( fwrite(soundbuf, sizeof(soundbuf)/2,1,fp) !=1)
              printf("fwrite failed\n");
        }
     else
        {
      //   printf("open failed\n");
        }
     fclose(fp);
    }	
#endif

  }
    return 0;
}

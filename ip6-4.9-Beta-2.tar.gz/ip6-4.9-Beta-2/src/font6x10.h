
void conv_cgrom( byte *mem);

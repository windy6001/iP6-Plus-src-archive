// ******************************************************
//   Build.h       iP6 Plus build number
//            by Windy
// *******************************************************

#define PROGRAM_NAME "iP6 Plus "
#define BUILD_VER    "4.9 Beta-2"
#define BUILD_DATE   "Build 2020/03/26"

#define AUTHOR       "Modified by Windy"
#define HOMEPAGE_URL "http://www.eonet.ne.jp/~windy/"
#define HELP_FILE    "HELP-4.8.html"



/*
	 Win32.h
   Programmed by Windy
*/
#ifndef _WIN32_H
#define _WIN32_H

#ifdef WIN32
#include <windows.h>
#endif


//#ifdef  GLOBAL
//#undef  EXTRN
//#define EXTRN
//#else
//#undef  EXTRN
//#define EXTRN extern
//#endif

#include "Win32stick.h"
#include "Win32fscr.h"

void SLEEP(int s);


void InitColor(void);

void PutImage(void);
void do_palet(int dest,int src);
int  messagebox(char *str, char *title);
void outputdebugstring(char *buff);
void putlasterror(void);

extern void choosefuncs(int lsbfirst, int bitpix);
extern void setwidth(int wide);
int setMenuTitle(int type);
int resizewindow( int bitmap_scale,int win_scale);

// ****************************************************************************
//          dibsection
// ****************************************************************************
typedef struct dibstruct {
	int					Width ,Height;		// size
	BYTE				*lpBMP;				// pixel buffer
	BITMAPINFO			*lpBmpInfo;			// Dibsection info
	BITMAPINFOHEADER	*lpBmpInfoh;		// BMP file info header
	HBITMAP				hBitmap1;			// bitmap handle
	HDC					hdcBmp;				// bitmap hdc
	} HIBMP;

HIBMP createIBMP(HWND hwnd, int width , int height, int bitpix);
void releaseIBMP(HIBMP hb);

//extern HWND hwndMain;
//extern HINSTANCE hInst;
//extern HICON     hIcon;

int InitMachine32(HINSTANCE hThisInst, HINSTANCE hPrevInst, LPSTR lpszArgs, int nWinMode);
LRESULT CALLBACK WindowFunc( HWND ,UINT ,WPARAM, LPARAM);


void ClearWindow(void);				//          ClearWindow: $B%&%$%s%I%&A4BN$r%/%j%"(B
void ClearStatusBar(void);          //          ClearStatusBar: $B%9%F!<%?%9%P!<$r%/%j%"(B
int textout(int x,int y,char *str); //          textout: $B%(%_%e%l!<%?$N2hLL$KJ8;z$r=PNO(B


void PutDiskAccessLamp(int sw);
void PutImage(void);

void putStatusBar(void);

int  debug_printf( char *fmt ,...);
extern int debug_level;

//#undef EXTRN
#endif

/** iP6: PC-6000/6600 series emualtor ************************/
/**                                                         **/
/**                           error.h                       **/
/** by Windy 2002-2003                                      **/
/*************************************************************/

#define PRINTDEBUG	debug_printf		//DEBUG PRINT
int debug_printf( char *fmt ,...);

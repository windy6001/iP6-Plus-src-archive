/** iP6: PC-6000/6600 series emualtor ************************/
/**                                                         **/
/**                         Xconf.h                         **/
/**                                                         **/
/** by ISHIOKA Hiroshi 1999                                 **/
/*************************************************************/

/* functions */
void Xt_init(int *argc, char ***argv);
void build_conf(void);
void run_conf(void);

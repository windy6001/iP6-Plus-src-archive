// ******************************************************
//   Build.h  for iP6 Plus build number$B!!!J%S%k%I%J%s%P!<!K(B
//            by Windy
// *******************************************************

#define PROGRAM_NAME "iP6 Plus 0.6.4 "
#define BUILD_NO     "Rel.4.7 "
#define BUILD_DATE   "(Build 2004/2/3)"

#define AUTHOR       "Modified by Windy"
#define HOMEPAGE_URL "www.kisweb.ne.jp/personal/windy/"
#define HELP_FILE    "HELP-4.7.html"

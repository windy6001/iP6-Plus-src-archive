/*
	MAKE  cgrom
	name is cgrom.h
*/

int make_extkanjirom(char *mem);

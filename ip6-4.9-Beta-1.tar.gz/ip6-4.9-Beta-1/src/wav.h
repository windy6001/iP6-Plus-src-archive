


struct _spec {
	int channels;
	int freq;
	int samplebit;
};


int loadWav( char *path ,struct _spec *spec, short **out_buff , int *len);
void freeWav( char *buff);


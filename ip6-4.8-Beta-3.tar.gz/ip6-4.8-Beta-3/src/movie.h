/** iP6: PC-6000/6600 series emualtor ************************/
/**                                                         **/
/**                        movie.h                          **/
/**                                                         **/
/** translate from PC6001V's C++ to C  by windy             **/
/**                                                         **/
/** Original program:   PC6001V                             **/
/** Original author:    Yumitaro.                           **/
/** Original URL:       http://www.papicom.net/p6v/         **/
/*************************************************************/
#ifndef MOVIE_H_INCLUDED
#define MOVIE_H_INCLUDED

//#include "sound.h"
#include "types.h"

#define BYTE  byte
#define WORD  word
#define DWORD dword


// RECT����
typedef struct {
	long left;		// LONG
	long top;		// LONG
	long right;		// LONG
	long bottom;	// LONG
} RECT6;

// RGBQUAD����
typedef struct {
	BYTE	b;
	BYTE	g;
	BYTE	r;
	BYTE	reserved;
} RGBPAL6;

// BITMAPINFOHEADER����
typedef struct {
	DWORD  biSize;
	long   biWidth;			// LONG
	long   biHeight;		// LONG
	WORD   biPlanes;
	WORD   biBitCount;
	DWORD  biCompression;
	DWORD  biSizeImage;
	long   biXPelsPerMeter;	// LONG
	long   biYPelsPerMeter;	// LONG
	DWORD  biClrUsed;
	DWORD  biClrImportant;
} BMPINFOHEADER6;

// MainAVIHeader����
typedef struct {
	DWORD dwMicroSecPerFrame;
	DWORD dwMaxBytesPerSec;
	DWORD dwReserved1;
	DWORD dwFlags;
	DWORD dwTotalFrames;
	DWORD dwInitialFrames;
	DWORD dwStreams;
	DWORD dwSuggestedBufferSize;
	DWORD dwWidth;
	DWORD dwHeight;
	DWORD dwReserved[4];
} MAINAVIHEADER6;

// AVIStreamHeader����
typedef struct {
	DWORD fccType;		// FOURCC
	DWORD fccHandler;	// FOURCC
	DWORD dwFlags;
	DWORD dwPriority;
	DWORD dwInitialFrames;
	DWORD dwScale;
	DWORD dwRate;
	DWORD dwStart;
	DWORD dwLength;
	DWORD dwSuggestedBufferSize;
	DWORD dwQuality;
	DWORD dwSampleSize;
	RECT6 rcFrame;
} AVISTRMHEADER6;

// AVIINDEXENTRY����
typedef struct {
	DWORD ckid;
	DWORD dwFlags;
	DWORD dwChunkOffset;
	DWORD dwChunkLength;
} AVIINDEXENTRY6;

// WAVEFORMATEX����
typedef struct {
	WORD  wFormatTag;
	WORD  nChannels;
	DWORD nSamplesPerSec;
	DWORD nAvgBytesPerSec;
	WORD nBlockAlign;
	WORD  wBitsPerSample;
	WORD  cbSize;
} WAVEFORMATEX6;



////////////////////////////////////////////////////////////////
// �N���X��`
////////////////////////////////////////////////////////////////
FILE *vfp;
MAINAVIHEADER6 vmh;
AVISTRMHEADER6 vsh, ash;
BMPINFOHEADER6 vbf;
RGBPAL6 pal[256];
WAVEFORMATEX6 awf;
	
int ABPP;					// bpp (8,16,24)
int src_ABPP;				// src bpp 

BOOL AVIRLE;				// RLE�t���O  TRUE:RLE  FALSE:�x�^
	
DWORD PosMOVI;
	
DWORD RiffSize;
DWORD MoviSize;
	
//cRing ABuf;					// �I�[�f�B�I�o�b�t�@
DWORD anum;					// �I�[�f�B�I�T���v�����J�E���g�p
	
//BOOL WriteHeader();						// �w�b�_�`�����N���o��
//BOOL WriteIndexr();						// �C���f�b�N�X�`�����N���o��
	
	
BOOL Init();							// ������

BOOL StartAVI( char *, int, int, int, int, int, BOOL );	// �r�f�I�L���v�`���J�n
void StopAVI();							// �r�f�I�L���v�`����~
BOOL IsAVI();							// �r�f�I�L���v�`����?

BOOL AVIWriteFrame();					// AVI1�t���[�����o��
#if 0
cRing *GetAudioBuffer();				// �I�[�f�B�I�o�b�t�@�擾
#endif

#define FGETBYTE(fp)		((BYTE)fgetc(fp))
#define FGETWORD(fp)		((WORD)(((BYTE)fgetc(fp))|((BYTE)fgetc(fp)<<8)))
#define FGETDWORD(fp)		((DWORD)(((BYTE)fgetc(fp))|((BYTE)fgetc(fp)<<8)|((BYTE)fgetc(fp)<<16)|((BYTE)fgetc(fp)<<24)))
#define FPUTBYTE(data,fp)	fputc(data&0xff,fp)
#define FPUTWORD(data,fp)	{ fputc(data&0xff,fp); fputc((data>>8)&0xff,fp); }
#define FPUTDWORD(data,fp)	{ fputc(data&0xff,fp); fputc((data>>8)&0xff,fp); fputc((data>>16)&0xff,fp); fputc((data>>24)&0xff,fp); }

#define CTODW(a,b,c,d)		((DWORD)(((BYTE)(a))|(((DWORD)((BYTE)(b)))<<8)|(((DWORD)((BYTE)(c)))<<16)|(((DWORD)((BYTE)(d)))<<24)))

#ifndef WORDS_BIGENDIAN

#define GET3BYTE(a,b,c,p)	{ a = *((BYTE *)p++); b = *((BYTE *)p++); c = *((BYTE *)p++); }
#define PUT3BYTE(a,b,c,p)	{ *((BYTE *)p++) = a; *((BYTE *)p++) = b; *((BYTE *)p++) = c; }
#define BTODW(a,b,c,d)		((DWORD)(((BYTE)(a))|(((DWORD)((BYTE)(b)))<<8)|(((DWORD)((BYTE)(c)))<<16)|(((DWORD)((BYTE)(d)))<<24)))
#define DWTOB(s,a,b,c,d)	{ a = (BYTE)((s>>24)&0x000000ff); b = (BYTE)((s>>16)&0x000000ff); c = (BYTE)((s>>8)&0x000000ff); d = (BYTE)(s&0x000000ff); }

#else

#define GET3BYTE(a,b,c,p)	{ c = *((BYTE *)p++); b = *((BYTE *)p++); a = *((BYTE *)p++); }
#define PUT3BYTE(a,b,c,p)	{ *((BYTE *)p++) = c; *((BYTE *)p++) = b; *((BYTE *)p++) = a; }
#define BTODW(a,b,c,d)		((DWORD)(((BYTE)(d))|(((DWORD)((BYTE)(c)))<<8)|(((DWORD)((BYTE)(b)))<<16)|(((DWORD)((BYTE)(a)))<<24)))
#define DWTOB(s,a,b,c,d)	{ d = (BYTE)((s>>24)&0x000000ff); c = (BYTE)((s>>16)&0x000000ff); b = (BYTE)((s>>8)&0x000000ff); a = (BYTE)(s&0x000000ff); }

#endif

#endif	// MOVIE_H_INCLUDED

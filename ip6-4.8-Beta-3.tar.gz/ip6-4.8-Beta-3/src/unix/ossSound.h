extern const struct plugin_struct sysdep_dsp_osssound;

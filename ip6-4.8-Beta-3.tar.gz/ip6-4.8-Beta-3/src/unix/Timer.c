#include <stdio.h>
#include <sys/time.h>

//#include <windows.h>
#include "../types.h"
#include "../Timer.h"

static struct timeval start;

void OSD_InitTimer(void)
	{
	gettimeofday(&start, NULL);
	}

void OSD_TrashTimer(void)
	{
	}

void OSD_Delay(int s)
	{
	 usleep( s* 1000);
	}

dword OSD_GetTicks(void)
	{
	struct timeval now;
	dword ticks;

	gettimeofday(&now, NULL);
	ticks=(now.tv_sec-start.tv_sec)*1000+(now.tv_usec-start.tv_usec)/1000;
	return(ticks);
	}



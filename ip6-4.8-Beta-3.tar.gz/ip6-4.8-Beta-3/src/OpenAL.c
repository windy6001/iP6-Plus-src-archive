#include <stdio.h>
#include <OpenAL/al.h>
#include <OpenAL/alc.h>

#include "types.h"
#include "sysdep/sysdep_dsp.h"
#include "sysdep/sysdep_dsp_priv.h"
#include "sysdep/plugin_manager.h"

int is_sound_playing;

// **************************************************
//		OpenAL 音源を開く
//   In:
//   Out: TRUE: success  FALSE: failed
// **************************************************
int openal_open(void)
{
    	return(1);
}


// **************************************************
//	   OpenAL 音源を閉じる
//    In:
//    Out:
// **************************************************
void openal_dsp_destroy(void)
{
}



// **************************************************
//	   ストリームに　書き込む
// **************************************************
void openal_dsp_write(struct sysdep_dsp_struct *dsp, short *src,int len)
{
}

// **************************************************
//		一時停止した音源を　再開する
// **************************************************
void openal_ResumeSound(void)
{
	is_sound_playing =TRUE;
}

// **************************************************
//		音源を一時停止する
// **************************************************
void openal_StopSound(void)
{
	is_sound_playing =FALSE;
}

// ****************************************************************************
//     waveout create
// ****************************************************************************
struct sysdep_dsp_struct * openal_dsp_create(const void *flags)
{
	const struct sysdep_dsp_create_params *params = flags;
	struct sysdep_dsp_struct *dsp = NULL;
	struct coreaudio_private *priv = NULL;

	dsp= malloc( sizeof( struct sysdep_dsp_struct));
	if( dsp == NULL)
		{
		 printf("malloc failed ¥n");
		 return NULL;
		}
	if( !openal_open())
		{
		 printf("OpenAL open failed ¥n");
		 return NULL;
		}

	dsp->write = openal_dsp_write;
	dsp->destroy = openal_dsp_destroy;
	dsp->resume =  openal_ResumeSound;
	dsp->stop   =  openal_StopSound;
	return dsp;
}

/*
 * The public variables structure
 */
const struct plugin_struct sysdep_dsp_openal = {
	"openal",
	"sysdep_dsp",
	"OpenAL plugin",
	NULL, 				/* no options */
	NULL,				/* no init */
	NULL,				/* no exit */
	openal_dsp_create,
	3,				/* high priority */
};





//
//  iP6_PlusAppDelegate.m
//  iP6 Plus
//
//  Created by うぃんでぃ on 09/11/14.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "iP6_PlusAppDelegate.h"
#ifdef USE_OPENGL
#import "EAGLView.h"
#endif
#import "TopmenuController.h"
#import "viewcontroller.h"


#import "../../src/os.h"
#import "../../src/sound.h"
#import "../../src/P6.h"
#import "../../src/mem.h"
#import "../../src/Option.h"
#import "../../src/buffer.h"
#import "../../src/build.h"

NSTimer * m_timerLoop;

@implementation iP6_PlusAppDelegate

@synthesize glView;

@synthesize window;
@synthesize p6view;
@synthesize p6keyboard_view;

extern int scale;
extern int P6Version;

@synthesize naviController;

int fullScreen=0;
int keyboardHidden=0;
//base_view * p6base_view;

NSTimer *hidden_timer;
void ConfigDelete(void);

//UILabel* label1;




// **************************************************
//		ナビゲーションバー　非表示するためのタイマー　セット
// **************************************************
-(void)setHiddenTimerNavigatorBar {
	if( !fullScreen)
		hidden_timer = [NSTimer scheduledTimerWithTimeInterval:(4.0) target:self selector:@selector(setToggleNavigatorBar) userInfo:nil repeats:NO];
}


// **************************************************
//		ナビゲーションバー　表示・非表示
// **************************************************
-(void)setToggleNavigatorBar {
	NSLog(@"setToggleNavigatorBar\n");
	fullScreen =!fullScreen;
	[naviController setNavigationBarHidden: fullScreen animated:NO];	// navigationbar display
	
//	[self setHiddenTimerNavigatorBar];
}

// **************************************************
//		キーボード　表示・非表示
// **************************************************
-(void)setKeybaordHidden:(BOOL)yes {

	[keyboard_viewcontroller setKeyboardHidden: yes]; // keyboard on/off
	keyboardHidden = yes;
}

// **************************************************
//
// **************************************************
-(void)openMenu {
	TopmenuController* topmenuController = [[[TopmenuController alloc] init] autorelease];
	[naviController pushViewController:topmenuController animated:YES];

	[hidden_timer release];
}


// **************************************************
//			起動処理
// **************************************************
-(BOOL)kidou
{
	BOOL status =NO;
	if(StartP6())				// init emulator
		{
		InitSound();
	
		// timer for Z80 CPU
		m_timerLoop = [NSTimer scheduledTimerWithTimeInterval:(1.0 / 60.0f) target:self selector:@selector(onTick) userInfo:nil repeats:YES];
	
#ifdef USE_OPENGL
		[glView startAnimation];
#endif
		status = YES;
		}
 return status;
}	



// **************************************************
//			アプリケーションの初期化処理
// **************************************************
- (void)applicationDidFinishLaunching:(UIApplication *)application {    

	usleep(1000000*0.3);	// splash screen wait 
    self.window.rootViewController = [UIViewController new];
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 30200
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) 	// iPad？
	{}
#endif
	
	// ****** bundle path ***********
	//NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	//NSString *documentsDirectory = [paths objectAtIndex:0];
	
	// ********** get current Directory **************
	NSString *homeDirectory = NSHomeDirectory();
    NSString *documentsDirectory = [homeDirectory stringByAppendingPathComponent:@"Documents"];
	const char *Path = [documentsDirectory UTF8String];
	
	OSD_SetModulePath( (char*)Path );
    
#if 0
    {
        label1 = [[[UILabel alloc]initWithFrame:CGRectZero]autorelease];
        label1.backgroundColor = [UIColor blueColor];
        label1.textColor = [UIColor whiteColor];
        CGPoint newPoint  = CGPointMake (50,50);
        label1.center = newPoint;
        [window addSubview: label1];
    }
#endif
    
    {
    
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        // ゲームコントローラが接続されたときの通知
        [center addObserver:self
                   selector:@selector(controllerDidConnect)
                       name:GCControllerDidConnectNotification
                     object:nil];
        // ゲームコントローラの接続が途絶えたときの通知
        [center addObserver:self
                   selector:@selector(controllerDidDisconnect)
                       name:GCControllerDidDisconnectNotification
                     object:nil];

    
    }
    
    
	
	{
		char buff[PATH_MAX];
		OSD_GetModulePath(buff ,PATH_MAX);
		printf(" Starting iP6 Plus.... \n Current Directory is '%s'\n", buff);
		InitVariable();
		scale = 1;
		P6Version= 4;
		UPeriod = 2;
		init_keybuffer();			// <--- init key buffer
		OSD_initKeymap();		// init keymap

		ConfigInit();				// <--- config init
		ConfigRead();				// <--- config read 
		UseSound= 1;

		//if(!chkOption( argc, argv)) return(0);	// <--- option check
		
		OSD_GetModulePath( RomPath ,1023);	// <--- RomPath
		//strcat( RomPath , "/../iP6 Plus.app/");
		strcat( RomPath , "/rom/");
		printf("RomPath is '%s'\n",RomPath);
		
		new_disk_num = disk_num = 1;
		scr4col = 1;
		FastTape= 1;

		
		ConfigWrite();				// <--- config write (àÍìxéwíËÇ≥ÇÍÇΩÉIÉvÉVÉáÉìÇäoÇ¶ÇÈ)
		
		{
			InitMachine();
			
			// rotation event  http://d.hatena.ne.jp/KishikawaKatsumi/20090510/1241968017
			[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
			[[NSNotificationCenter defaultCenter] addObserver:self
													 selector:@selector(didRotate:)
														 name:UIDeviceOrientationDidChangeNotification
													   object:nil];
			
			window.backgroundColor= [UIColor darkGrayColor];    // 背景色を、設定
			
			keyboard_viewcontroller = [[viewcontroller alloc] initWithNibName:nil bundle:nil];

			naviController = [[UINavigationController alloc]init ];
			
			//UIControllerViewを追加
			[naviController pushViewController: keyboard_viewcontroller animated:NO];
			
			
			[self setToggleNavigatorBar ];			//バーを隠す
						
			// ステータスバー/ナビゲーションバー/ツールバーを透過
			//[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleBlackTranslucent;
			naviController.navigationBar.barStyle = UIBarStyleBlack;
			naviController.navigationBar.translucent = YES;
			naviController.toolbar.barStyle = UIBarStyleBlack;
			naviController.toolbar.translucent = YES;
			
			
			//[window addSubview: keyboard_viewcontroller.view];
			[window addSubview: naviController.view];
			
			if([self kidou]==NO)		// ------------ kidou failed ----------------
				{
				window.backgroundColor= [UIColor redColor];

				UIAlertView *alert = [[UIAlertView alloc] 
								  initWithTitle:@"" 
								  message:@"   iP6 Plus   Initialize failed \n Required BIOS ROM  \n Get a BIOS ROM! " 
								  delegate:nil 
								  cancelButtonTitle:@"OK" 
								  otherButtonTitles:nil];
				[alert show];
				[alert release];
				
/*				CGRect rect= CGRectMake(0,40,320,30);
				UILabel* label = [[UILabel alloc] initWithFrame:rect];
				label.text = @"        iP6 Plus " BUILD_NO "";
				label.backgroundColor = [UIColor redColor];

				[window addSubview: label];
				[label release];
*/				
				ConfigDelete();
				[self setToggleNavigatorBar ];		// ナビゲーションバー　表示する
				[self openMenu];	// メニューを開く
				}

		 // Override point for customization after application launch
		 [window makeKeyAndVisible];
			
		}
	}	

}


- (void)setEventController:(GCController *)controller
{
   // __weak typeof(self); weakSelf = self;
    
    // ポーズボタンイベント
  //  controller.controllerPausedHandler = ^(GCController *controller) {
  //      [self pausedOnController:controller];
  //  };
  //  label1.text = @"game Controller event recieved ";
    if (!self.gamepad && controller.gamepad) {
        self.gamepad = controller.gamepad;
        // それぞれのボタンイベント
        self.gamepad.valueChangedHandler = ^(GCGamepad *gamepad, GCControllerElement *element) {
            if (gamepad.buttonA.isPressed) stick0 |= STICK0_SPACE;
            if (gamepad.dpad.up.isPressed)      stick0 |= STICK0_UP;
            if (gamepad.dpad.down.isPressed)    stick0 |= STICK0_DOWN;
            if (gamepad.dpad.right.isPressed)   stick0 |= STICK0_RIGHT;
            if (gamepad.dpad.left.isPressed)   stick0 |= STICK0_LEFT;
 
            // 十字キーのX軸：gamepad.dpad.xAxis.value
            // 十字キーのY軸：gamepad.dpad.yAxis.value
        };
    }
    
    // Aボタンだけのイベント
    self.gamepad.buttonA.valueChangedHandler = ^(GCControllerButtonInput *button, float value, BOOL pressed) {
        if (pressed) NSLog(@"pressedButtonA");
    };
}

#pragma mark - NSNotificationCenter
- (void)controllerDidConnect
{
    //self.myLabel.text = @"GamePad Connected";
    
   // label1.text = @"connected Game Controller";
    NSArray *controllers = [GCController controllers];
    for (GCController *controller in controllers) {
        [self setEventController:controller];
    }
}

- (void)controllerDidDisconnect
{
   // label1.text = @"disconnected Game Controller";

    self.myLabel.text = @"GamePad Disconnected";
    self.gamepad = nil;
}



// **************************************************
//		画面の回転
// **************************************************
-(void)rotateScreenWithOrientation:(UIDeviceOrientation)orientation
{
#ifdef USE_OPENGL
	[glView rotateScreenWithOrientation: orientation];
#endif
    
#if 1
	// rotate
	[[UIApplication sharedApplication] setStatusBarOrientation: UIInterfaceOrientationLandscapeRight];
	
#endif
#if 0
    float angle = 0.0;
    UIScreen *screen = [UIScreen mainScreen];
	glView.bounds = CGRectMake( 0.0f , 0.0f , screen.bounds.size.width ,
							   screen.bounds.size.height );
	glView.transform = CGAffineTransformConcat( glView.transform, 
											   CGAffineTransformMakeRotation( M_PI *angle/ 180.0f));
#endif


 }

// **************************************************
//			デバイスが回転したときに、呼び出される
// **************************************************
- (void) didRotate:(NSNotification *)notification {
    UIDeviceOrientation orientation = [[notification object] orientation];
	
    if (orientation == UIDeviceOrientationLandscapeLeft) 
		{
        NSLog(@"landscape left <--\n");
		[self setKeybaordHidden: YES];		// キーボードを非表示
		[self rotateScreenWithOrientation: orientation];
			
		//p6keyboard_view.hidden = YES;		// keyboard is hidden
		} 
	else if (orientation == UIDeviceOrientationLandscapeRight) 
		{
        NSLog(@"landscape right -->\n");
		[self setKeybaordHidden: YES];		// キーボードを非表示
		[self rotateScreenWithOrientation: orientation];
		}
	else if (orientation == UIDeviceOrientationPortraitUpsideDown)
		{
		NSLog(@"portrate upside down \n");
		[self setKeybaordHidden: NO];		// キーボードを非表示
		[self rotateScreenWithOrientation: orientation];
		}
	else if (orientation == UIDeviceOrientationPortrait) 
		{
		NSLog(@"portrate  \n");
		[self setKeybaordHidden: NO];		// キーボードを表示
		[self rotateScreenWithOrientation: orientation];
		}
}

// **************************************************
//			タイマーで、Z80 CPUを、定期的に呼び出す。
// **************************************************
- (void)onTick
{
#ifndef USE_OPENGL
	static int cnt=0;
#endif
	
	CPUThreadProc(NULL);

#ifndef USE_OPENGL
	if( ++cnt % 2)
		[p6view setNeedsDisplay];
#endif
}

// **************************************************
//			終了時の後処理
// **************************************************
- (void)dealloc {
	TrashP6();
	TrashMachine();

	[p6view release];
    [window release];
	[glView release];
	[m_timerLoop release];
	
    [super dealloc];
}

// **************************************************
//
// **************************************************
- (void) applicationWillResignActive:(UIApplication *)application
{
#ifdef USE_OPENGL
	[glView stopAnimation];
#endif
}

// **************************************************
//
// **************************************************
- (void) applicationDidBecomeActive:(UIApplication *)application
{
#ifdef USE_OPENGL
	[glView startAnimation];
#endif
}

// **************************************************
//
// **************************************************
- (void)applicationWillTerminate:(UIApplication *)application
{
#ifdef USE_OPENGL
	[glView stopAnimation];
#endif
}


@end


// **** emulation view ****
//p6view = [[view alloc] initWithFrame:[window frame]];

// **** keybard view ****
//p6keyboard_view = [[keyboard_view alloc] initWithFrame:CGRectMake(0,0,120,480)];

//オブジェクト(window)をウィンドウに追加
//[window addSubview:p6view];			// add emulation view
//[window addSubview:p6keyboard_view];	// add keyboard view


//[p6view setNeedsDisplay];

//p6keyboard_view= [[keyboard_view alloc] initWithFrame: CGRectMake(0,200-BASE_YY,320,480-200+BASE_YY)];
//[window addSubview: p6keyboard_view];

//p6view= [[view alloc] initWithFrame: CGRectMake(0,200,320,280)];
//[window addSubview: p6view];


//
//  viewcontroller.h
//  iP6_Plus
//
//  Created by うぃんでぃ on 09/12/05.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface viewcontroller : UIViewController {



}
-(void)setKeyboardHidden:(BOOL)yes;

@end

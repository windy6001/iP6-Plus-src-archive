//
//  OpenDiskController.m
//  iP6_Plus
//
//  Created by うぃんでぃ on 10/04/01.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "iP6_PlusAppDelegate.h"
#import "../../src/P6.h"
#import "../../src/mem.h"
#import "OpenExtRomController.h"
#import "../../src/Option.h"

@implementation OpenExtRomController

enum {A_RESET};		// アラートの識別し

//int alert_type;		// アラートの種類

static int selected_idx;   // 選択された　禁書目録番号

#pragma mark UIViewController methods



// *****************************************************
//		viewDidLoad
// *****************************************************
- (void)viewDidLoad {
	[super viewDidLoad];
	
	self.title = @"Open Ext ROM";				// メニュー
	if ( !items_ ) {					// メニューアイテム
		NSString *homedirectory = NSHomeDirectory();
		NSString *dir = [homedirectory stringByAppendingPathComponent:@"Documents/extrom"];
		
		NSArray *array = [[NSFileManager defaultManager]directoryContentsAtPath: dir];	// directory contents
						 

		items_ = [[NSMutableArray alloc] initWithCapacity: 1];
		
		if( [array count] >0)
		{
			id dat;							// ディレクトリの内容が、最終的に、items_ に入る
			for( dat in array) {
				[items_ addObject: dat];
			}
		}
		else 
		{
			[items_ addObject: @"なし  (empty)"];
		}
		
		//NSIndexPath *indexPath = [NSIndexPath  indexPathForRow:0 inSection:0 ];
		//[self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition: UITableViewScrollPositionNone animated:NO];
		
	} 
}

// *****************************************************
//		Done ボタンが押された
// *****************************************************
-(void)buttonDidPush {
	
	char path[1024];
	OSD_GetModulePath( path, 1024);
	strcat(path , "/extrom/");
	
	NSString *filename = [items_ objectAtIndex: selected_idx];
	//NSLog(@"selected dskpath='%s' dskname='%s'",DskPath , DskName);
	
	
	//strcpy( DskName[0] , [filename cStringUsingEncoding:NSUTF8StringEncoding]);
	//strcpy( DskPath[0] , path);
	//OpenFile1(FILE_DISK);
	ConfigWrite();

	
	[filename release];
	
	[self.navigationController popViewControllerAnimated:YES];	// 設定画面に戻る
	
	
}

// *****************************************************
//		Cancel ボタンが押された
// *****************************************************
-(void)buttonCancelPush {
	[self.navigationController popViewControllerAnimated:YES];	// 設定画面に戻る
	
}


// *****************************************************
//		view 現れた　　　　　ナビゲーションのボタンの設定
// *****************************************************
-(void) viewWillAppear:(BOOL) animated {
	[super viewWillAppear:animated];
	
	[self.navigationController setNavigationBarHidden:NO animated:NO];
	[self.navigationController setToolbarHidden:YES animated:NO];
	
	UIBarButtonItem *done_button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemDone
																				 target:self
																				 action:@selector(buttonDidPush)];
	UIBarButtonItem *cancel_button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemCancel
																				   target:self
																				   action:@selector(buttonCancelPush)];
	self.navigationItem.leftBarButtonItem  = cancel_button;
	self.navigationItem.rightBarButtonItem = done_button;

}


#pragma mark UITableView methods

// *****************************************************
//			メニューアイテムの数を返す
// *****************************************************
- (NSInteger)tableView:(UITableView*)tableView
 numberOfRowsInSection:(NSInteger)section
{
	return [items_ count];
}

// *****************************************************
//			
// *****************************************************
- (UITableViewCell*)tableView:(UITableView*)tableView
		cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	
	NSString* title = [items_ objectAtIndex:indexPath.row];
	cell.textLabel.text = [title stringByReplacingOccurrencesOfString:@"SampleFor" withString:@""];
	
	return cell;
}



// *****************************************************
//			メニューアイテムが選択された
// *****************************************************
- (void)tableView:(UITableView*)tableView
didSelectRowAtIndexPath:(NSIndexPath*)indexPath
{
	selected_idx = indexPath.row;
	
	 return;
}

@end

//
//  LoadTapeController.h
//  iP6_Plus
//
//  Created by うぃんでぃ on 10/04/01.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface OpenTapeController : UITableViewController <UIAlertViewDelegate> {
@private
	NSMutableArray * items_;
	NSArray * sections_;
	NSArray * dataSource_;
	

}


@end

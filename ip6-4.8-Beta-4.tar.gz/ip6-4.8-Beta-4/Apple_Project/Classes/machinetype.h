//
//  machinetype.h
//  iP6_Plus
//
//  Created by うぃんでぃ on 10/05/15.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//


#define M_0	"PC-6001"
#define M_1	"PC-6001mkII"
#define M_2 "PC-6001mkIISR"
#define M_3	"PC-6601"
#define M_4	"PC-6601SR"

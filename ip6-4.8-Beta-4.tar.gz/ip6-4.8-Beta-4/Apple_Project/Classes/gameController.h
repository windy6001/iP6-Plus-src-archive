//
//  NSObject_gameController.h
//  iP6_Plus
//
//  Created by うぃんでぃ on 2016/06/05.
//
//

#import <GameController/GameController.h>

@interface gameController: NSObject

@end

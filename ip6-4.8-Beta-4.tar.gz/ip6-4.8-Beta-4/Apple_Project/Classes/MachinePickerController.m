//
//  MachinePickerController.m
//  iP6_Plus
//
//  Created by うぃんでぃ on 10/05/15.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MachinePickerController.h"
#import "machinetype.h"
#import "iP6_PlusAppDelegate.h"
#import "../../src/P6.h"

@implementation MachinePickerController

enum {A_REBOOT};
static int alert_type;

static NSArray *machineString;
static UIPickerView * picker;

// *****************************************************
//		機種番号　設定		（初期値もらう）
// *****************************************************
-(void)setMachineType: (int)inp {
	//MachineType = inp;
}


// *****************************************************
//		viewがロードされた　　　機種ピッカーの初期化
// *****************************************************
-(void)viewDidLoad {
	[super viewDidLoad];
	
	machineString = [[NSArray alloc] initWithObjects:(id) @M_0 ,@M_1,@M_2,@M_3,@M_4,nil ];

	picker = [[[UIPickerView alloc] init ] autorelease];
	picker.delegate = self; //delegate
	picker.dataSource = self; // dataSource
	
	picker.showsSelectionIndicator = YES; // 選択行明示
	[picker selectRow: newP6Version inComponent:0 animated:NO];	//　ピッカーを移動する
    picker.backgroundColor = [UIColor whiteColor];
	[self.view addSubview:picker];
}


// *****************************************************
//			アラートのボタンが押された
// *****************************************************
-(void)alertView: (UIAlertView*) alertView clickedButtonAtIndex:(NSInteger) buttonIndex {
#if 0
  NSLog(@"alert push button \n");
	/* ------- リセット --------- */
	if( buttonIndex != alertView.cancelButtonIndex) {
		if( alert_type ==A_REBOOT)
		{
			
			ConfigWrite();	// save
			ResetPC(1);		// reboot
			
			[self.navigationController popViewControllerAnimated:YES];	// 設定画面に戻る
			//[self.navigationController popToRootViewControllerAnimated:YES];	// ルート画面まで戻る
			
			iP6_PlusAppDelegate *appDelegate = (iP6_PlusAppDelegate *)[[UIApplication sharedApplication]delegate]; // ナビゲーション隠す
			[appDelegate setToggleNavigatorBar];

		}
	}
#endif
}


// *****************************************************
//		Done ボタンが押された
// *****************************************************
-(void)buttonDidPush {
	
	NSInteger row = [picker selectedRowInComponent:0];
	NSLog( @"picker selected %d  %@ \n",row ,[machineString objectAtIndex: row]);
	newP6Version = row;

	[self.navigationController popViewControllerAnimated:YES];	// 設定画面に戻る

/*
	alert_type = A_REBOOT;
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"　確認　"
													message:@"機種を変更して、再起動しても良いですか？"
												   delegate:self
										  cancelButtonTitle:nil
						                  otherButtonTitles:@"いいえ", @"はい", nil]; 
	
	alert.cancelButtonIndex = 0;
	[alert show];
	[alert release];
*/	
	
}

// *****************************************************
//		Cancel ボタンが押された
// *****************************************************
-(void)buttonCancelPush {
	[self.navigationController popViewControllerAnimated:YES];	// 設定画面に戻る

}

// *****************************************************
//		view 現れた　　　　　ナビゲーションのボタンの設定
// *****************************************************
-(void) viewWillAppear:(BOOL) animated {
	[super viewWillAppear:animated];
	
	[self.navigationController setNavigationBarHidden:NO animated:NO];
	[self.navigationController setToolbarHidden:YES animated:NO];
	
    
	UIBarButtonItem *done_button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemDone
																		 target:self
																		 action:@selector(buttonDidPush)];
	UIBarButtonItem *cancel_button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemCancel
																		 target:self
																		 action:@selector(buttonCancelPush)];
	self.navigationItem.leftBarButtonItem  = cancel_button;
	self.navigationItem.rightBarButtonItem = done_button;
	
}

// *****************************************************
//		ピッカーの列数を返す
// *****************************************************
-(NSInteger) numberOfComponentsInPickerView:(UIPickerView*) pickerView {
	return 1;	// 列数
}
	
// *****************************************************
//		ピッカーの行数を返す
// *****************************************************
-(NSInteger)pickerView:(UIPickerView*)pickerView numberOfRowsInComponent:(NSInteger)component {
	return 5;		// 行数
}

// *****************************************************
//		ピッカーに設定する、文字列を返す
// *****************************************************
-(NSString*)pickerView:(UIPickerView*)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
	return [machineString objectAtIndex: row];
}
	
	

@end

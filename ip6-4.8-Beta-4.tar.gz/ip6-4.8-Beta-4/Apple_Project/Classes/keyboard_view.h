//
//  keyboard_view.h
//  iP6_Plus
//
//  Created by うぃんでぃ on 09/12/01.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define BASE_YY 200 

@interface keyboard_view : UIView {
	UINavigationController *naviController;

}

//- (id)shrink:(BOOL)flag;

@end

//
//  GameViewController.h
//  game
//
//  Created by windy6001 on 2019/07/03.
//  Copyright © 2019 windy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>
#import "Renderer.h"

// Our iOS view controller
@interface GameViewController : UIViewController

@end

//
//  ES1Renderer.m
//  test10
//
//  Created by うぃんでぃ on 10/03/08.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//
#define USE_QUARTZ

#ifdef USE_OPENGL

#import "ES1Renderer.h"
#import "../../src/Refresh.h"

OSD_Surface *getRefreshSurface(void);

@implementation ES1Renderer

// Create an ES 1.1 context
// **************************************************
//    init
//
// **************************************************
- (id) init
{
	//printf("ES1Renderer init \n");

	if (self = [super init])
	{
		context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES1];
        
        if (!context || ![EAGLContext setCurrentContext:context])
		{
            [self release];
            return nil;
        }
		
		// Create default framebuffer object. The backing will be allocated for the current layer in -resizeFromLayer
		glGenFramebuffersOES(1, &defaultFramebuffer);
		glGenRenderbuffersOES(1, &colorRenderbuffer);
		glBindFramebufferOES(GL_FRAMEBUFFER_OES, defaultFramebuffer);
		glBindRenderbufferOES(GL_RENDERBUFFER_OES, colorRenderbuffer);
		glFramebufferRenderbufferOES(GL_FRAMEBUFFER_OES, GL_COLOR_ATTACHMENT0_OES, GL_RENDERBUFFER_OES, colorRenderbuffer);
	}
	
	return self;
}

// **************************************************
//    loadTextureName
//
// **************************************************
//- (void)loadTextureName:(NSString*)imageName texture:(GLuint*)texture
void loadTexture( GLuint* texture)
{
	int width , height;
	//printf("loadTexture \n");
	
	// get surface
	//CGContextRef dst_cgcontext = UIGraphicsGetCurrentContext();
	OSD_Surface *src_surface = getRefreshSurface();
	//CGContextRef src_cgcontext = src_surface->context;
	//CGImageRef   cgImage = CGBitmapContextCreateImage( src_cgcontext);

	GLubyte*    data;
	data = (GLubyte*) src_surface->pixels;
	width  = src_surface->w;
	height = src_surface->h;
	
	
    // テクスチャを作成する
    if( !*texture ) glGenTextures(1, texture);
	
    // テクスチャをバインドする
    glBindTexture(GL_TEXTURE_2D, *texture);
	
    // ビットマップ画像を設定する
	
	//printf("width =%d  height=%d \n",width, height );
	
    glTexImage2D(
				 GL_TEXTURE_2D, 0, GL_RGBA, 
				 width, height,
				 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
	
    // テクスチャの設定を行う
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
   // glEnable(GL_TEXTURE_2D);
   // glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
   // glEnable(GL_BLEND);
}

// **************************************************
//    drawBackground
//
// **************************************************
- (void)drawBackground
{
	//printf("drawBackground \n");
    // 頂点を作成する
/*    GLfloat vertices[] = {
        -1.0f, 0.3f, 
        1.0f,  0.3f, 
        -1.0f, 1.5f, 
        1.0f, 1.5f
    };
*/
    GLfloat vertices[] = {
        -1.0f, -1.5f, 
        1.0f,  -1.5f, 
        -1.0f, 1.5f, 
        1.0f, 1.5f
    };
    glVertexPointer(2, GL_FLOAT, 0, vertices);
	
    // 色を設定する
    GLubyte colors[] = {
        255, 255, 255, 255, 
        255, 255, 255, 255, 
        255, 255, 255, 255, 
        255, 255, 255, 255, 
    };
    glColorPointer(4, GL_UNSIGNED_BYTE, 0, colors);
	
    // テクスチャの設定をする (テクスチャの一部を使用する）
    GLfloat coord[] = {
        0                , 1.0f*200.0/512.0*(480.0/200.0),
        1.0f*320.0/512.0 , 1.0f*200.0/512.0*(480.0/200.0), 
        0     , 0        , 
        1.0f*320.0/512.0 , 0
    };

	
	glPushMatrix();					// Push matrix
	glEnable( GL_TEXTURE_2D);		// Enable texture future
	
	
    glTexCoordPointer(2, GL_FLOAT, 0, coord);
	
    // 描画を行なう
    glBindTexture(GL_TEXTURE_2D, backTexture);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    glBindTexture(GL_TEXTURE_2D, 0);

	glDisable( GL_TEXTURE_2D);		// disalbe texture future
	glPopMatrix();					// pop matrix
}


-(void)rotateScreenWithOrientation:(UIDeviceOrientation)orientation {
	
	if( orientation == UIDeviceOrientationLandscapeLeft)
		{
			// rotation (right home) 
			glMatrixMode( GL_MODELVIEW);
			glLoadIdentity();				// init matrix convert
			//glScalef(1.5f , 1.5f , 1.0f);	// scale
            glScalef(1.0f , 1.5f , 1.0f);	// scale
			
			//glRotatef( 270 , 0.0 , 0.0 , 1.0f);	//rotation
			//glTranslatef( 0.0f , -0.835f , 0.0);  //move
            glTranslatef( 0.0f , -1.0f , 0.0);  //move
		}
	else if( orientation == UIDeviceOrientationLandscapeRight)
		{
			// rotation (left home) 
			glMatrixMode( GL_MODELVIEW);
			glLoadIdentity();				// init matrix convert
            //glScalef(1.5f , 1.5f , 1.0f);	// scale
            //glScalef(1.2f , 1.2f , 1.0f);	// scale
			
			//glRotatef( 90 , 0.0 , 0.0 , 1.0f);	//rotation
			//glTranslatef( 0.0f , -0.835f , 0.0);  //move
            glTranslatef( -0.2f , -1.0f , 0.0);  //move
		}
	else if( orientation == UIDeviceOrientationPortraitUpsideDown )
		{
		// rotation (home up side down) 
		glMatrixMode( GL_MODELVIEW);
		glLoadIdentity();				// init matrix convert
		//glScalef(1.5f , 1.5f , 1.0f);	// scale
		
		//glRotatef( 180 , 0.0 , 0.0 , 1.0f);	//rotation
		//glTranslatef( 0.0f , 0.0f , 0.0);  //move
		}
	else if( orientation == UIDeviceOrientationPortrait)
	{
		// rotation (home) 
		glMatrixMode( GL_MODELVIEW);
		glLoadIdentity();				// init matrix convert
	/*	glScalef(1.5f , 1.5f , 1.0f);	// scale
		
		glRotatef( 180 , 0.0 , 0.0 , 1.0f);	//rotation
		glTranslatef( 0.0f , -0.835f , 0.0);  //move
	 */
	}
	
	[self drawBackground];
}

// **************************************************
//    render
//
// **************************************************
- (void) render
{
	//static int doneflag = 0;
	
	//if( doneflag ==0)
		{
		//doneflag=1;
		// Replace the implementation of this method to do your own custom drawing
 	
		// This application only creates a single context which is already set current at this point.
		// This call is redundant, but needed if dealing with multiple contexts.
		// set EAGL context
		[EAGLContext setCurrentContext:context];
    
		// This application only creates a single default framebuffer which is already bound at this point.
		// This call is redundant, but needed if dealing with multiple framebuffers.
		// set frame buffer
		glBindFramebufferOES(GL_FRAMEBUFFER_OES, defaultFramebuffer);

		// set viewport  2D
		glViewport(0, 0, backingWidth, backingHeight);
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrthof( -1.0f, 1.0f , -1.5f, 1.5f , -1.0f , 1.0f);
        //glOrthof( -1.0f, 1.0f , -1.5f, 1.5f ,  0.5f , -0.5f); //
	
		//glOrthof( -1.5f, 1.5f , -1.0f, 1.0f ,  0.5f , -0.5f);	//rotate  for iPad ?
		glMatrixMode(GL_MODELVIEW);
	
		/*glLoadIdentity();
		 glTranslatef(0.0f, (GLfloat)(sinf(transY)/2.0f), 0.0f);
		 transY += 0.075f; */
	
		// clear buffer
		// glClearColor(0.5f, 0.5f, 0.5f, 1.0f);
		// glClear(GL_COLOR_BUFFER_BIT);
    
		//glVertexPointer(2, GL_FLOAT, 0, squareVertices);
		glEnableClientState(GL_VERTEX_ARRAY);
		//glColorPointer(4, GL_UNSIGNED_BYTE, 0, squareColors);
		glEnableClientState(GL_COLOR_ARRAY);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		}
    //glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
	
	//if( !backTexture) 
	loadTexture( &backTexture);
	
	[self drawBackground];
	

	// This application only creates a single color renderbuffer which is already bound at this point.
	// This call is redundant, but needed if dealing with multiple renderbuffers.
    // show buffer 
	glBindRenderbufferOES(GL_RENDERBUFFER_OES, colorRenderbuffer);
    [context presentRenderbuffer:GL_RENDERBUFFER_OES];

	usleep(1);
}



// **************************************************
//    resizeFromLayer
//
// **************************************************
- (BOOL) resizeFromLayer:(CAEAGLLayer *)layer
{	
	// Allocate color buffer backing based on the current layer size
    glBindRenderbufferOES(GL_RENDERBUFFER_OES, colorRenderbuffer);
    [context renderbufferStorage:GL_RENDERBUFFER_OES fromDrawable:layer];
	glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_WIDTH_OES, &backingWidth);
    glGetRenderbufferParameterivOES(GL_RENDERBUFFER_OES, GL_RENDERBUFFER_HEIGHT_OES, &backingHeight);
	
    if (glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES) != GL_FRAMEBUFFER_COMPLETE_OES)
	{
		NSLog(@"Failed to make complete framebuffer object %x", glCheckFramebufferStatusOES(GL_FRAMEBUFFER_OES));
        return NO;
    }
    
    return YES;
}


// **************************************************
//    dealloc
//
// **************************************************
- (void) dealloc
{
	// Tear down GL
	if (defaultFramebuffer)
	{
		glDeleteFramebuffersOES(1, &defaultFramebuffer);
		defaultFramebuffer = 0;
	}

	if (colorRenderbuffer)
	{
		glDeleteRenderbuffersOES(1, &colorRenderbuffer);
		colorRenderbuffer = 0;
	}
	
	// Tear down context
	if ([EAGLContext currentContext] == context)
        [EAGLContext setCurrentContext:nil];
	
	[context release];
	context = nil;
	
	[super dealloc];
}

@end
#endif


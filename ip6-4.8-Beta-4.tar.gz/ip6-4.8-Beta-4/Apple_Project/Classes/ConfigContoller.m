//
//  ConfigController.m
//
//  Created by ToKoRo on 2009-09-24.
//
//  設定画面

#import "machinetype.h"
#import "ConfigController.h"
#import "MachinePickerController.h"
#import "iP6_PlusAppDelegate.h"
#import "../../src/P6.h"
#import "../../src/Sound.h"
#import "../../src/Option.h"
#import "../../src/mem.h"

#pragma mark ----- Private Methods Definition -----

@interface ConfigController ()
- (UIImageView*)imageViewForCell:(const UIView*)cell withFileName:(NSString*)fileName;
- (UISwitch*)switchForCell:(const UIView*)cell;
- (UISlider*)sliderForCell:(const UIView*)cell;
@end 

#pragma mark ----- Start Implementation For Methods -----

@implementation ConfigController

UISwitch *diskSwitch;
UISwitch *soundSwitch;
UISwitch *extramSwitch;

static NSArray *machineString;

int alert_type;
enum {A_REBOOT};

int switch_type;
enum {SW_DISK ,SW_SOUND ,SW_EXTRAM};

- (void)dealloc {
	[sections_ release];
	[dataSource_ release];

	[super dealloc];
}


// *****************************************************
//			初期設定
// *****************************************************

- (id)init {
	if ( (self = [super initWithStyle:UITableViewStyleGrouped]) ) {
	}
	machineString = [[NSArray alloc] initWithObjects:(id) @M_0 ,@M_1,@M_2,@M_3,@M_4,nil ];

	return self;
}

// *****************************************************
//         View がロードされたとき    セルの初期化
// *****************************************************
- (void)viewDidLoad {
  [super viewDidLoad];
	
	

  // 表示するデータを作成
  sections_ = [[NSArray alloc] initWithObjects: @"機種", @"必殺技", @"強さ",@"hoge", nil ];
  NSArray* rows1 = [NSArray arrayWithObjects: @"機種", nil ];
  NSArray* rows2 = [NSArray arrayWithObjects: @"ディスク", nil ];
  NSArray* rows3 = [NSArray arrayWithObjects: @"サウンド", nil ];
  NSArray* rows4 = [NSArray arrayWithObjects: @"拡張メモリー", nil ];
  dataSource_ = [[NSArray alloc] initWithObjects: rows1, rows2, rows3, rows4, nil ];
	
	
	UIBarButtonItem *done_button = [[UIBarButtonItem alloc] initWithBarButtonSystemItem: UIBarButtonSystemItemDone
																				 target:self
																				 action:@selector(buttonDidPush)];
	self.navigationItem.rightBarButtonItem = done_button;
	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return [sections_ count];
}

- (NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
  return [[dataSource_ objectAtIndex:section] count];
}




// *****************************************************
//                セルの内容を設定
// *****************************************************
- (UITableViewCell*)tableView:(UITableView*)tableView
  cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
  static NSString* identifier = @"basis-cell";
  UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
  if ( nil == cell ) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                  reuseIdentifier:identifier];
    [cell autorelease];
  }
  cell.textLabel.text =
    [[dataSource_ objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
  switch ( indexPath.section ) {
    case 0: //< セルに機種名表示
	  {
		  UILabel *label = [[[UILabel alloc]init] autorelease];		// 機種名表示用　ラベル
		  label.frame = cell.bounds;
		  label.textAlignment = UITextAlignmentCenter;
		  label.text = [machineString  objectAtIndex: newP6Version];			// ここで現在の機種を表示する
																// 最初は、現在の機種で、ピッカーで変化したら、新しい機種
		  [cell.contentView addSubview:label];
      //[cell.contentView addSubview:[self imageViewForCell:cell withFileName:@"Samurai.png"]];
      }
	  break;
      case 1: //< セルにUISwitchを追加
		  switch_type = SW_DISK;
		  diskSwitch = [self switchForCell:cell];
		  [cell.contentView addSubview: diskSwitch];
		  break;
	  case 2: //< セルにUISwitchを追加
		  switch_type = SW_SOUND;
		  soundSwitch = [self switchForCell:cell];
		  [cell.contentView addSubview: soundSwitch];
		  break;
	  case 3: //< セルにUISwitchを追加
          switch_type = SW_EXTRAM;
          extramSwitch = [self switchForCell:cell];
		  [cell.contentView addSubview:extramSwitch];
		  break;
    default:
		  break;
  }
  return cell;
}


// *****************************************************
//			 セルを選択したとき
// *****************************************************
-(void)tableView:(UITableView*) tableView didSelectRowAtIndexPath:(NSIndexPath*)indexPath {
	NSLog(@"table selected %d",indexPath.row);
	if( indexPath.row ==0)				// 機種の設定が選択された
		{										// 機種ピッカーに切り替え
		MachinePickerController *viewController = [[[MachinePickerController alloc]init] autorelease];
		[self.navigationController pushViewController:viewController animated:YES]; 
		}
}


// *****************************************************
//			セルによって縦幅を変更する
// *****************************************************
- (CGFloat)tableView:(UITableView*)tableView heightForRowAtIndexPath:(NSIndexPath*)indexPath {
  if ( 0 == indexPath.section ) {
    return 100.0;
  } else {
    return 44.0;
  }
}

#pragma mark ----- Private Methods -----

- (UIImageView*)imageViewForCell:(const UITableViewCell*)cell withFileName:(NSString*)fileName {
/*  UIImage* image = [UIImage imageNamed:fileName];
  UIImageView* theImageView = [[[UIImageView alloc] initWithImage:image] autorelease];
  CGPoint newCenter = cell.contentView.center;
  newCenter.x += 80;
  theImageView.center = newCenter;
  theImageView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin |
                                  UIViewAutoresizingFlexibleRightMargin |
                                  UIViewAutoresizingFlexibleTopMargin |
                                  UIViewAutoresizingFlexibleBottomMargin;
  return theImageView;
*/
}

// *****************************************************
//			スイッチ
// *****************************************************
- (UISwitch*)switchForCell:(const UITableViewCell*)cell {
  UISwitch* theSwitch = [[[UISwitch alloc] init] autorelease];
	
  switch( switch_type)
	{
		case SW_DISK:   theSwitch.on = new_disk_num; break;
		case SW_SOUND:  theSwitch.on = newUseSound; break;
        case SW_EXTRAM: theSwitch.on = new_use_extram64; break;
		default:        theSwitch.on = YES; break;
	}
  CGPoint newCenter = cell.contentView.center;
  newCenter.x += 80;
  theSwitch.center = newCenter;
  theSwitch.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin |
                               UIViewAutoresizingFlexibleRightMargin |
                               UIViewAutoresizingFlexibleTopMargin |
                               UIViewAutoresizingFlexibleBottomMargin;
  return theSwitch;
}

// *****************************************************
//			スライダー
// *****************************************************
- (UISlider*)sliderForCell:(const UITableViewCell*)cell {
  UISlider* theSlider = [[[UISlider alloc] init] autorelease];
  theSlider.value = theSlider.maximumValue / 2;
  theSlider.frame = CGRectMake( 0, 0, cell.bounds.size.width / 2, cell.bounds.size.height );
  CGPoint newCenter = cell.contentView.center;
  newCenter.x += 50;
  theSlider.center = newCenter;
  theSlider.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin |
                               UIViewAutoresizingFlexibleRightMargin |
                               UIViewAutoresizingFlexibleTopMargin |
                               UIViewAutoresizingFlexibleBottomMargin;
  return theSlider;
}




// *****************************************************
//			アラートのボタンが押された
// *****************************************************
-(void)alertView: (UIAlertView*) alertView clickedButtonAtIndex:(NSInteger) buttonIndex {
	NSLog(@"alert push button \n");
	/* ------- リセット --------- */
	if( buttonIndex != alertView.cancelButtonIndex) {
		if( alert_type ==A_REBOOT)
		{
			new_disk_num = diskSwitch.on;		// disk on/off
			newUseSound = soundSwitch.on;		// sound on/off
            new_use_extram64 = extramSwitch.on;
			
			ConfigWrite();	// save
			ResetPC(1);		// reboot
			
			//[self.navigationController popViewControllerAnimated:YES];	// 設定画面に戻る
			[self.navigationController popToRootViewControllerAnimated:YES];	// ルート画面まで戻る
			
			iP6_PlusAppDelegate *appDelegate = (iP6_PlusAppDelegate *)[[UIApplication sharedApplication]delegate]; // ナビゲーション隠す
			[appDelegate setToggleNavigatorBar];
		}
	}
}


// *****************************************************
//		Done ボタンが押された
// *****************************************************
-(void)buttonDidPush {
	
/*	NSInteger row = [picker selectedRowInComponent:0];
	NSLog( @"picker selected %d  %@ \n",row ,[machineString objectAtIndex: row]);
	newP6Version = row;
*/
	
	alert_type = A_REBOOT;
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"　確認　"
													message:@"設定を変更して、再起動しても良いですか？"
												   delegate:self
										  cancelButtonTitle:nil
						                  otherButtonTitles:@"いいえ", @"はい", nil]; 
	
	alert.cancelButtonIndex = 0;
	[alert show];
	[alert release];
	
	
}

// *****************************************************
//		Cancel ボタンが押された
// *****************************************************
-(void)buttonCancelPush {
	[self.navigationController popViewControllerAnimated:YES];	// 設定画面に戻る
	
}

@end

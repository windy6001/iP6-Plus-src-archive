//
//  keyboard_view.m
//  iP6_Plus
//
//  Created by うぃんでぃ on 09/12/01.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//



#import "keyboard_view.h"
#import "iP6_PlusAppDelegate.h"
#import "TopmenuController.h"
#import "../../src/keys.h"
//#import "../../src/mac/mackey.h"
#import "../../src/P6.h"
#import "../../src/mem.h"

@implementation keyboard_view



// **************************************************
//			キーボード　タイプ
// **************************************************
#define	IPHONE_QWERTY_KEYBOARD       0x10
#define	IPHONE_123_KEYBOARD          0x20
#define IPHONE_KANA_KEYBOARD         0x01
#define IPHONE_GAME_KEYBOARD         0x40

// **************************************************
//			カラー
// **************************************************
#define CL_REVERSE 0x00aa88
#define CL_WHITE   0xffffff
#define CL_BALCK   0x000000


#define END_OF_DATA -1



int  touch_flag = 0;			// 1:touching   0: no touch
int  touch_osdkeycode  = 0;		// touching osd keycode

int  isKanaMode = 0;			// 1:kana    0: non kana
int  keyboard_type= IPHONE_QWERTY_KEYBOARD;	// keyboard type
int  pre_keyboard_type = -1;			// pre keyboard type

//int  base_yy =BASE_YY;			// keyboard base line

int  first_osdkeycode[2];		// drag first keycode
CGPoint dragfirstPoint;			// drag first point

int  isFlikKeyboard=0;		    // 1:kana flik keyboard popup


BOOL shiftlock_flag = NO;		// YES: shift lock  NO: shift unlock

CGFloat start_x;				// screen flick start xy
CGFloat start_y;

NSTimer *keyRepeatTimer;

NSTimer *flikKeyboardTimer;

// ****** COPY Structer ********
#define COPY_STRUCT(dest,src) \
{ \
int i=0;\
do {\
dest[i] = src[i];\
if( dest[i].x == END_OF_DATA) break;\
i++;\
}while(1);\
}

#define PUSH_STRUCT( src)  COPY_STRUCT(pre_keyboard , src)

#define POP_STRUCT( dest)  COPY_STRUCT(dest , pre_keyboard);

// *******************************************
//		KEYBOARD TABLE
// 
// *******************************************
struct keyboard_data {
	int x,y;
	int w,h;
	char *title;
	int  osdkeycode;
};


// ------- QWERTY KEYBOARD ----------------
struct keyboard_data iphone_qwerty_keyboard[] ={
{  0,  5 ,30,27,"ESC", OSDK_ESCAPE},
{ 40,  5 ,40,27,"F1", OSDK_F1},
{ 90,  5 ,40,27,"F2", OSDK_F2},
{140,  5 ,40,27,"F3", OSDK_F3},
{190,  5 ,40,27,"F4", OSDK_F4},
{240,  5 ,40,27,"F5", OSDK_F5},


{290,  5 ,40,27,"DEL" , OSDK_BACKSPACE},

{ 00, 50 ,25,35,"Q" , OSDK_Q},
{ 36, 50 ,25,35,"W" , OSDK_W},
{ 68, 50 ,25,35,"E" , OSDK_E},
{100, 50 ,25,35,"R" , OSDK_R},
{132, 50 ,25,35,"T" , OSDK_T},
{164, 50 ,25,35,"Y" , OSDK_Y},
{196, 50 ,25,35,"U" , OSDK_U},
{228, 50 ,25,35,"I" , OSDK_I},
{260, 50 ,25,35,"O" , OSDK_O},
{292, 50 ,25,35,"P" , OSDK_P},

{  4,105 ,25,35,"A" , OSDK_A},
{ 36,105 ,25,35,"S" , OSDK_S},
{ 68,105 ,25,35,"D" , OSDK_D},
{100,105 ,25,35,"F" , OSDK_F},
{132,105 ,25,35,"G" , OSDK_G},
{164,105 ,25,35,"H" , OSDK_H},
{196,105 ,25,35,"J" , OSDK_J},
{228,105 ,25,35,"K" , OSDK_K},
{260,105 ,25,35,"L" , OSDK_L},

{290,105 ,25,35,"INS" ,OSDK_INSERT},



{ 36,160 ,25,35,"Z" , OSDK_Z},
{ 68,160 ,25,35,"X" , OSDK_X},
{100,160 ,25,35,"C" , OSDK_C},
{132,160 ,25,35,"V" , OSDK_V},
{164,160 ,25,35,"B" , OSDK_B},
{196,160 ,25,35,"N" , OSDK_N},
{228,160 ,25,35,"M" , OSDK_M},

{  0,160 ,25,35,"Shift", OSDK_SHIFT},

//{  0,200 ,25,35,"MODE", OSDK_MODE},
{ 0,200 ,25,35,"PAGE", OSDK_PAGEUP},

{  0,245 ,25,35,"STOP", OSDK_PAUSE},


{ 30,245 ,28 ,35,"123",OSDK_123},
{ 65,245 ,28 ,35,"かな",OSDK_KANA},
{100,245 ,110,35," SPACE " , OSDK_SPACE},
{275,155 ,45 ,40,"RET" , OSDK_RETURN},

{255,205 ,28 ,30,"↑" , OSDK_UP},
{220,245 ,28 ,35,"←" , OSDK_LEFT},
{255,245 ,28 ,35,"↓" , OSDK_DOWN},
{290,245 ,28 ,35,"→" , OSDK_RIGHT},


{END_OF_DATA},

};

// ------- GAME KEYBOARD ----------------
struct keyboard_data iphone_game_keyboard[] ={
{  0,200 ,90,70," SPACE " , OSDK_SPACE},
	
{140,100 ,59 ,59,"\\" , OSDK_LEFTUP},
{200,100 ,59 ,59,"↑" , OSDK_UP},
{260,100 ,59 ,59,"/" , OSDK_RIGHTUP},

{140,160 ,59 ,59,"←" , OSDK_LEFT},
{200,160 ,59 ,59," " , 0},
{260,160 ,59 ,59,"→" , OSDK_RIGHT},

{140,220 ,59 ,59,"/" , OSDK_LEFTDOWN},
{200,220 ,59 ,59,"↓" , OSDK_DOWN},
{260,220 ,59 ,59,"\\" , OSDK_RIGHTDOWN},
	
{ 0, 30 ,25,35,"123",OSDK_123},

{END_OF_DATA},
	
};

// ------- suuji KEYBOARD----------------
struct keyboard_data iphone_suuji_keyboard[] ={
{  0,   5 ,25,35,"1", OSDK_1},
{ 36,   5 ,25,35,"2", OSDK_2},
{ 68,   5 ,25,35,"3", OSDK_3},
{100,   5 ,25,35,"4", OSDK_4},
{132,   5 ,25,35,"5", OSDK_5},
{164,   5 ,25,35,"6", OSDK_6},
{196,   5 ,25,35,"7", OSDK_7},
{228,   5 ,25,35,"8", OSDK_8},
{260,   5 ,25,35,"9", OSDK_9},
{292,   5 ,25,35,"0", OSDK_0},

{  0,  50 ,25,35,"!", OSDK_EXCLAMATION},	// shift+1
{ 36,  50 ,25,35,"\x22",OSDK_DOUBLEQUOTE},	// shift+2
{ 68,  50 ,25,35,"#" ,OSDK_HASH},			// shift+3
{100,  50 ,25,35,"$" ,OSDK_DOLLAR},			// shift+4
{132,  50 ,25,35,"%" ,OSDK_PERCENT},		// shift+5
{164,  50 ,25,35,"&" ,OSDK_AND},			// shift+6
{196,  50 ,25,35,"'" ,OSDK_QUOTE},			// shift+7
{228,  50 ,25,35,"(" ,OSDK_LEFTPAREN},		// shift+8
{260,  50 ,25,35,")" ,OSDK_RIGHTPAREN},		// shift+9
{290,  50 ,40,27,"DEL" , OSDK_BACKSPACE},

{290,  80 ,40,27,"INS" ,OSDK_INSERT},


{  0, 105 ,25,35,";", OSDK_SEMICOLON},
{ 36, 105 ,25,35,":", OSDK_COLON},
{ 68, 105 ,25,35,"[", OSDK_LEFTBRACKET},
{100, 105 ,25,35,"]", OSDK_RIGHTBRACKET},
{132, 105 ,25,35,"@", OSDK_AT},
{164, 105 ,25,35,"_", OSDK_UNDERSCORE_KIGOU},		// shift+ロ
{196, 105 ,25,35,"¥", OSDK_BACKSLASH},
{228, 105 ,25,35,"<", OSDK_LESS},			// shift+ ,
{260, 105 ,25,35,">", OSDK_GREATER},		// shift+ .
{290, 105 ,25,35,"?", OSDK_QUESTION},		// shift+ /



{  0, 160 ,25,35,"+", OSDK_PLUS},		// shift+ ;
{ 36, 160 ,25,35,"-", OSDK_MINUS},
{ 68, 160 ,25,35,"*", OSDK_ASTERISK},	// shift+ :
{100, 160 ,25,35,"/", OSDK_SLASH},
{132, 160 ,25,35,"=", OSDK_EQUALS},		// shift+ -
{164, 160 ,25,35,",", OSDK_COMMA},
{196, 160 ,25,35,".", OSDK_PERIOD},

{ 0,200 ,25,35,"PAGE", OSDK_PAGEUP},
{  0,245 ,25,35,"STOP", OSDK_PAUSE},
{30, 245 ,25,35,"ABC",OSDK_ABC},
{30, 200 ,25,35,"GAME",OSDK_GAME},

//{  0,165 ,25,35,"Shift", OSDK_SHIFT},

{ 65,245 ,28 ,35,"かな" ,OSDK_KANA},
{100,245 ,110,35," SPACE " , OSDK_SPACE},
{275,155 ,45 ,40,"RET" , OSDK_RETURN},

{255,205 ,28 ,30,"↑" , OSDK_UP},
{220,245 ,28 ,35,"←" , OSDK_LEFT},
{255,245 ,28 ,35,"↓" , OSDK_DOWN},
{290,245 ,28 ,35,"→" , OSDK_RIGHT},


{END_OF_DATA},

};


// ------- kana KEYBOARD----------------
struct keyboard_data iphone_kana_keyboard[] ={
//{  0,  34 ,63,63,"GAME",OSDK_GAME},
{  0,  34 ,63,63,"  ",0},

{ 64,  34 ,63,63,"あ", OSDK_3},
{128,  34 ,63,63,"か", OSDK_T},
{192,  34 ,63,63,"さ", OSDK_X},
{256,  34 ,63,63,"DEL", OSDK_BACKSPACE},

{  0,  98 ,63,63,"Shift",OSDK_SHIFT},
{ 64,  98 ,63,63,"た", OSDK_Q},
{128,  98 ,63,63,"な", OSDK_U},
{192,  98 ,63,63,"は", OSDK_F},
{256,  98 ,63,63,"SPC", OSDK_SPACE},

{  0, 162 ,63,63,"123",OSDK_123},
{ 64, 162 ,63,63,"ま", OSDK_J},
{128, 162 ,63,63,"や", OSDK_7},
{192, 162 ,63,63,"ら", OSDK_O},

{  0, 226 ,63,63,"ABC", OSDK_ABC},
{ 64, 226 ,63,63,"　 ", 0},
{128, 226 ,63,63,"わ", OSDK_0},
{192, 226 ,63,63,"、", OSDK_KUTOUTEN},
{256, 162 ,63,128," RET", OSDK_RETURN},

{END_OF_DATA},

};



// ------- kana AIUEO flik KEYBOARD----------------

struct keyboard_data aiueo_keyboard[] = {
{64   ,34   , 63,63 ,"あ",OSDK_3},
{64-64,34   , 63,63 ,"い",OSDK_E},
{64   ,34-64, 63,63 ,"う",OSDK_4},
{64+64,34   , 63,63 ,"え",OSDK_5},
{64   ,34+64, 63,63 ,"お",OSDK_6},
{END_OF_DATA},

};

// ------- kana KAKIKUKEKO KEYBOARD----------------
struct keyboard_data kakikukeko_keyboard[]= {
{128   ,34   ,63,63,"か", OSDK_T},
{128-64,34   ,63,63,"き", OSDK_G},
{128   ,34-64,63,63,"く", OSDK_H},
{128+64,34   ,63,63,"け", OSDK_COLON},
{128   ,34+64,63,63,"こ", OSDK_B},
{END_OF_DATA},
};

// ------- kana SASISUSESO KEYBOARD----------------

struct keyboard_data sasisuseso_keyboard[]= {
{192    ,34   ,63,63,"さ", OSDK_X},
{192-64 ,34   ,63,63,"し", OSDK_D},
{192    ,34-64,63,63,"す", OSDK_R},
{192+64 ,34   ,63,63,"せ", OSDK_P},
{192    ,34+64,63,63,"そ", OSDK_C},
{END_OF_DATA},
};

// ------- kana TATITUTETO KEYBOARD----------------
struct keyboard_data tatituteto_keyboard[]= {
{ 64    ,98   ,63,63,"た", OSDK_Q},
{ 64-64 ,98   ,63,63,"ち", OSDK_A},
{ 64    ,98-64,63,63,"つ", OSDK_Z},
{ 64+64 ,98   ,63,63,"て", OSDK_W},
{ 64    ,98+64,63,63,"と", OSDK_S},
{END_OF_DATA},
};

// ------- kana NANINUNENO KEYBOARD----------------

struct keyboard_data naninuneno_keyboard[]={	
{128    ,98   ,63,63,"な", OSDK_U},
{128-64 ,98   ,63,63,"に", OSDK_I},
{128    ,98-64,63,63,"ぬ", OSDK_1},
{128+64 ,98   ,63,63,"ね", OSDK_COMMA},
{128    ,98+64,63,63,"の", OSDK_K},
{END_OF_DATA},
};


struct keyboard_data hahihuheho_keyboard[]={	
{192    ,98   ,63,63,"は", OSDK_F},
{192-64 ,98   ,63,63,"ひ", OSDK_V},
{192    ,98-64,63,63,"ふ", OSDK_2},
{192+64 ,98   ,63,63,"へ", OSDK_UPPER},
{192    ,98+64,63,63,"ほ", OSDK_MINUS},
{END_OF_DATA},
};

struct keyboard_data mamimumemo_keyboard[]={
{ 64    ,162    ,63,63,"ま", OSDK_J},
{ 64-64 ,162    ,63,63,"み", OSDK_N},
{ 64    ,162-64 ,63,63,"む", OSDK_RIGHTBRACKET},
{ 64+64 ,162    ,63,63,"め", OSDK_SLASH},
{ 64    ,162+64 ,63,63,"も", OSDK_M},
{END_OF_DATA},
};
	
struct keyboard_data yayuyo_keyboard[]={
{128    ,162    ,63,63,"や", OSDK_7},
{128    ,162-64 ,63,63,"ゆ", OSDK_8},
{128    ,162+64 ,63,63,"よ", OSDK_9},
{END_OF_DATA},
};

	
struct keyboard_data rarirurero_keyboard[]={
{192     ,162    ,63,63,"ら", OSDK_O},
{192-64  ,162    ,63,63,"り", OSDK_L},
{192     ,162-64 ,63,63,"る", OSDK_PERIOD},
{192+64  ,162    ,63,63,"れ", OSDK_SEMICOLON},
{192     ,162+64 ,63,63,"ろ", OSDK_UNDERSCORE},
{END_OF_DATA},
};
	
struct keyboard_data wawon_keyboard[]={
{128     ,226    ,63,63,"わ", OSDK_0},
{128-64  ,226    ,63,63,"を", OSDK_WO},
{128     ,226-64 ,63,63,"ん", OSDK_Y},
{128+64  ,226    ,63,63,"ー", OSDK_BACKSLASH},
{END_OF_DATA},
};


struct keyboard_data kutouten_keyboard[]={
{192     ,226    ,63,63,"、", OSDK_KUTOUTEN},
{192-64  ,226    ,63,63,"。", OSDK_TOUTEN},
//{128     ,226-64 ,63,63,"　", 0},
//{128+64  ,226    ,63,63,"　", 0},
{END_OF_DATA},
};


/*
struct _flick_keyboards {
	int osdkeycode;
	struct keyboard_data keyboard;
} flick_keyboards[]= {
{OSDK_3, aiueo_keyboard},
{OSDK_T, kakikukeko_keyboard},
{OSDK_X, sasisuseso_keyboard},
{OSDK_Q, tatituteto_keyboard},
{OSDK_U, naninuneno_keyboard},
{OSDK_F, hahihuheho_keyboard},
{OSDK_J, mamimumemo_keyboard},
{OSDK_7, yayuyo_keyboard},
{OSDK_0, wawon_keyboard},
};
*/

/* ********* kigou henkan table ************ */
struct {
	int osdkeycode;
	int keycode[5];
} kigou_tbl[] = {
	{OSDK_EXCLAMATION ,{SHIFT_DOWN , OSDK_1, SHIFT_UP}},
	{OSDK_DOUBLEQUOTE ,{SHIFT_DOWN , OSDK_2, SHIFT_UP}},
	{OSDK_HASH        ,{SHIFT_DOWN , OSDK_3, SHIFT_UP}},
	{OSDK_DOLLAR      ,{SHIFT_DOWN , OSDK_4, SHIFT_UP}},
	{OSDK_PERCENT     ,{SHIFT_DOWN , OSDK_5, SHIFT_UP}},
	{OSDK_AND         ,{SHIFT_DOWN , OSDK_6, SHIFT_UP}},
	{OSDK_QUOTE       ,{SHIFT_DOWN , OSDK_7, SHIFT_UP}},
	{OSDK_LEFTPAREN   ,{SHIFT_DOWN , OSDK_8, SHIFT_UP}},
	{OSDK_RIGHTPAREN  ,{SHIFT_DOWN , OSDK_9, SHIFT_UP}},
	
	{OSDK_UNDERSCORE_KIGOU  ,{SHIFT_DOWN , OSDK_UNDERSCORE, SHIFT_UP}},
	{OSDK_LESS        ,{SHIFT_DOWN , OSDK_COMMA , SHIFT_UP}},
	{OSDK_GREATER     ,{SHIFT_DOWN , OSDK_PERIOD, SHIFT_UP}},
	{OSDK_QUESTION    ,{SHIFT_DOWN , OSDK_SLASH , SHIFT_UP}},
	{OSDK_PLUS        ,{SHIFT_DOWN , OSDK_SEMICOLON , SHIFT_UP}},
	{OSDK_ASTERISK    ,{SHIFT_DOWN , OSDK_COLON , SHIFT_UP}},
	{OSDK_EQUALS      ,{SHIFT_DOWN , OSDK_MINUS , SHIFT_UP}},

	{OSDK_WO          ,{SHIFT_DOWN , OSDK_0     , SHIFT_UP}},
	
	{OSDK_LEFTUP      ,{OSDK_LEFT  , OSDK_UP    }},
	{OSDK_RIGHTUP     ,{OSDK_RIGHT , OSDK_UP    }},
	{OSDK_LEFTDOWN    ,{OSDK_LEFT  , OSDK_DOWN  }},
	{OSDK_RIGHTDOWN   ,{OSDK_RIGHT , OSDK_DOWN  }},
	
	{OSDK_KUTOUTEN    ,{SHIFT_DOWN , OSDK_COMMA , SHIFT_UP}},
	{OSDK_TOUTEN      ,{SHIFT_DOWN , OSDK_PERIOD, SHIFT_UP}},
	
	
	{END_OF_DATA},

};


struct keyboard_data current_keyboard[100];	// current keybaord

struct keyboard_data pre_keyboard[100];		// pre keyboard

// **************************************************
//    UTF8 strlen
//
// **************************************************
unsigned int UTF8_strlen( const char *_value){
	char* value = (char*)_value ;
	unsigned int count = 0;
	unsigned int bytes = strlen(value) ;
	
	for(int bi=0;bi <bytes ; ) {
		unsigned char ucb = *(unsigned char*)value ;
		++count ;
		if( ucb <= 127 ){ ++bi ; ++value ; continue ;}
		while( ucb&0x80 ){ ucb<<=1 ; ++bi ; ++value ; }
		
		}
	return count ;
}

// **************************************************
//    check button
//
// **************************************************
int check_button( int px , int py) {
	int osdkeycode=0;
	int i;
	if( py>200-30)		/* -64で、かなキーボードを荒涼 */
		{
		for(i=0; current_keyboard[i].x != END_OF_DATA; i++)
			{
			int sx = current_keyboard[i].x;
			int sy = current_keyboard[i].y + BASE_YY;
			int ex = current_keyboard[i].w + sx;
			int ey = current_keyboard[i].h + sy;
		
			if( sx < px && px < ex && sy < py  && py <ey)
				{
				osdkeycode = current_keyboard[i].osdkeycode;
				break;
				}
		
			}
		}
	else
		{			// ------ screen flicking on the screen  (8 direction )---------　
		CGFloat dx,dy,aa,bb;
		
		dx = px- start_x; dy = py- start_y; aa= 50; bb=45;

		if( dx > aa )
			{
			if( dy < -bb)     { osdkeycode = OSDK_RIGHTUP;}
			else if( dy > bb) { osdkeycode = OSDK_RIGHTDOWN;}
			else              { osdkeycode = OSDK_RIGHT;}
			}
		else if( dx < -bb)
			{
			if( dy < -bb)     { osdkeycode = OSDK_LEFTUP;}
			else if( dy >bb)  { osdkeycode = OSDK_LEFTDOWN;}
			else              { osdkeycode = OSDK_LEFT; }
			}
		else if( dy > bb)  { osdkeycode = OSDK_DOWN; }
		else if( dy < -bb) { osdkeycode = OSDK_UP;   }
		}
	
	return osdkeycode;
}




int check_kigou( int osdkeycode ,int *line)
{
	int i=0;
	int ret =0;
	//if( isKanaMode ) return ret;		// kana mode is do nothing 
	
	do {
		if( osdkeycode == kigou_tbl[i].osdkeycode)
			{
			*line = i;
			ret=1;
			break;
			}
		i++;

	}
	while( kigou_tbl[i].osdkeycode != END_OF_DATA);
	return ret;
}

// **************************************************
//    keyevent execute
//
// **************************************************
int keyevent_execute(int px, int py) {
	//int i;
	int line;

	int osdkeycode = check_button( px, py);
	if( osdkeycode == OSDK_SHIFT)
		{
		int scancode=0;

		shiftlock_flag = !shiftlock_flag;
		if(shiftlock_flag) 
			write_keybuffer( keybuffer, 0x10, 1,     scancode , OSDK_SHIFT ); // SHIFT DOWN
		else 
			write_keybuffer( keybuffer, 0x10, 0,     scancode , OSDK_SHIFT ); // SHIFT UP
		return 0;
		}
			
	else if( osdkeycode == OSDK_123)
		{
		COPY_STRUCT( current_keyboard , iphone_suuji_keyboard);
		pre_keyboard_type = keyboard_type;
		keyboard_type = IPHONE_123_KEYBOARD;
		}
	else if( osdkeycode == OSDK_ABC)
		{
		COPY_STRUCT( current_keyboard , iphone_qwerty_keyboard);
		pre_keyboard_type = keyboard_type;
		keyboard_type = IPHONE_QWERTY_KEYBOARD;
		}
	else if( osdkeycode == OSDK_KANA)
		{
		COPY_STRUCT( current_keyboard , iphone_kana_keyboard);
		pre_keyboard_type = keyboard_type;
		keyboard_type = IPHONE_KANA_KEYBOARD;
		}
	else if( osdkeycode == OSDK_GAME)
		{
		COPY_STRUCT( current_keyboard , iphone_game_keyboard);
		pre_keyboard_type = keyboard_type;
		keyboard_type = IPHONE_GAME_KEYBOARD;
		}
	else if( check_kigou( osdkeycode , &line) )
		{
		for(int i=0; i<5; i++)
			{
				int scancode=0;
				osdkeycode = kigou_tbl[line].keycode[i];
				switch( osdkeycode)
					{
					case SHIFT_DOWN: write_keybuffer( keybuffer, 0x10, 1,     scancode , OSDK_SHIFT ); break;
					case SHIFT_UP:   write_keybuffer( keybuffer, 0x10, 0,     scancode , OSDK_SHIFT ); break;
					case 0 :         i=100; break;		// loop break
					default:         write_keybuffer( keybuffer, 0x10, 1,     scancode , osdkeycode ); 
									 write_keybuffer( keybuffer, 0x10, 0,     scancode , osdkeycode ); 
									break;
					}

				 
			}
		}
	else if( osdkeycode )
		{

		int scancode = 0;
		write_keybuffer( keybuffer, 0x10, 1,     scancode , osdkeycode );
		write_keybuffer( keybuffer, 0x10, 0,     scancode , osdkeycode );
		//write_keybuffer(asc, keydown , kcode , p6keycode);
		}
	
	if(( pre_keyboard_type == IPHONE_KANA_KEYBOARD && isKanaMode) || (keyboard_type == IPHONE_KANA_KEYBOARD&& !isKanaMode))	
		{
		int scancode = 0;
		osdkeycode = OSDK_SCROLLOCK;
		write_keybuffer( keybuffer, 0x10, 1,     scancode , osdkeycode ); // push kana key
		write_keybuffer( keybuffer, 0x10, 0,     scancode , osdkeycode );
		isKanaMode = !isKanaMode;
		}

	if(shiftlock_flag ==YES)
		{
			int scancode=0;
		write_keybuffer( keybuffer, 0x10, 0,     scancode , OSDK_SHIFT ); // SHIFT UP
		shiftlock_flag = NO;
		}
	return 0;
}



//@synthesize p6keyboard_image;
UIImage *image;

// **************************************************
//		初期化
// **************************************************
- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
			// Initialization code
		
		COPY_STRUCT(current_keyboard , iphone_qwerty_keyboard);
	//	self.backgroundColor = [UIColor blackColor];
		self.backgroundColor = [UIColor clearColor];

    }
    return self;
}

// **************************************************
//		四角形　描画
// **************************************************
void put_rectangle( CGContextRef dst_cgcontext , int x ,int y , int w , int h , int flag ,int color)
{
	int r = (color >>16) & 0xff;
	int g = (color >>8) & 0xff;
	int b = (color & 0xff);
	
	if( flag )
	{
	CGContextSetRGBFillColor( dst_cgcontext, r ,g ,b,0xff);   // fill color
	CGRect rect2 = CGRectMake( x ,y ,w, h);
	CGContextFillRect( dst_cgcontext ,rect2);
	}
	else
	{
	CGContextSetRGBStrokeColor( dst_cgcontext, r ,g ,b,0xff);   // color
	CGRect rect2 = CGRectMake( x ,y ,w, h);
	CGContextStrokeRect( dst_cgcontext ,rect2);
	}
}

// **************************************************
//		文字列描画
// **************************************************
void put_string(int x,int y ,int w, int h , char * title ,int color)
{
// ---------- put string ------------
	int r = (color >>16) & 0xff;
	int g = (color >>8) & 0xff;
	int b = (color & 0xff);
	UIColor *col = [UIColor colorWithRed: r green: g blue: b alpha: 0xff];
	[col set];

	int fontsize;
	int len = UTF8_strlen( title);
	
	fontsize = w /len;
	if( fontsize <=9) fontsize=9;
	/*if( len <2)  fontsize = 26;
	else if( len==2) fontsize= 16;
	else if( len >=3) fontsize = 11;
	 */

	NSString *string = [[NSString alloc] initWithUTF8String:title];
	[string drawAtPoint:CGPointMake(x, y) withFont:[UIFont systemFontOfSize: fontsize]];
	[string release];
}


// **************************************************
//    drawRect :  keyboard update to UIView
//
// **************************************************
- (void)drawRect:(CGRect)rect {
	int idx=-1;
	CGContextRef dst_cgcontext = UIGraphicsGetCurrentContext();
	
	int i=0;
	do {
		// ------ put rectangle -------------
		int x = current_keyboard[i].x;
		int y = current_keyboard[i].y +BASE_YY;
		int w = current_keyboard[i].w;
		int h = current_keyboard[i].h;
		char *title = current_keyboard[i].title;
		int osdkeycode = current_keyboard[i].osdkeycode;
		if( x == END_OF_DATA) break;

		if( osdkeycode == touch_osdkeycode && touch_flag )		// touching keyboard ....
			{
			idx= i;			// found idx
			if( keyboard_type == IPHONE_KANA_KEYBOARD  ) // reverse color
				{
				put_rectangle( dst_cgcontext , x , y ,w ,h ,1 ,CL_REVERSE);
				put_string( x, y+1 , w, h , title ,CL_BALCK);
				}
			else									  // popup animation
				{
				int dy= 40; 
				int zzz=10;
			
				put_rectangle( dst_cgcontext , x , y ,w ,h ,0 ,CL_WHITE);
				put_rectangle( dst_cgcontext , x-zzz   , y-zzz-dy   , w+zzz*2, h+zzz*2 , 1 ,CL_WHITE);	// keyboard popup
				put_rectangle( dst_cgcontext , x-zzz+2 , y-zzz-dy+2 , w+zzz*2, h+zzz*2 , 0 ,CL_BALCK);	// keyboard popup
				put_string( x -zzz/2+2, y-zzz-dy ,w+zzz*2 ,h+zzz*2 , title ,CL_BALCK);					// keyboard popup 
				}
			}
		else
			{
			int color;;
			if(osdkeycode == OSDK_SHIFT && shiftlock_flag==YES)		// shift key lock
				color = CL_REVERSE;
			else 
				color = CL_WHITE;

			put_rectangle( dst_cgcontext , x , y ,w ,h ,1 ,color);
			put_string( x, y , w, h , title ,0x000000);
			}

		i++;
	}
	while(1);
	
}

// **************************************************
//    dealloc
//
// **************************************************
- (void)dealloc {
    [super dealloc];
}


// **************************************************
//		keyRepeatFunc
// Auto keyrepeat 
// **************************************************
- (void)KeyRepeatFunc {
	static int keydown=1;
	static int scancode=0;
	//if(first_osdkeycode[0] == OSDK_SPACE)
	 //  keydown = !keydown;		// 一旦０になるのを見ているゲームで、連射する
	
	write_keybuffer( keybuffer, 0x10, keydown,     scancode , first_osdkeycode[0] ); 
	
//	keyevent_execute(start_x, start_y);
	keyboard_set_stick( first_osdkeycode[0] ,keydown);		// ゲーム入力　オートキーリピート

}

/*
-(void)flikKeyboardOpen:(NSTimer*)inp
{
	NSString *value =  [[inp userInfo] objectForKey:@"key1"];
	char *tmp = [value cStringUsingEncoding: NSUTF8StringEncoding];
	int osdkeycode = atoi( tmp);
	
	if( osdkeycode==OSDK_3 || osdkeycode==OSDK_T || osdkeycode==OSDK_X || osdkeycode==OSDK_Q
	   ||osdkeycode==OSDK_U || osdkeycode==OSDK_F || osdkeycode==OSDK_J || osdkeycode==OSDK_7
	   ||osdkeycode==OSDK_O || osdkeycode==OSDK_0)
	{
	isFlikKeyboard =1;
	PUSH_STRUCT( current_keyboard);
	}

	switch( osdkeycode)
	{
	case OSDK_3: COPY_STRUCT( current_keyboard, aiueo_keyboard);break;
	case OSDK_T: COPY_STRUCT( current_keyboard, kakikukeko_keyboard);break;
	case OSDK_X: COPY_STRUCT( current_keyboard, sasisuseso_keyboard);break;
	case OSDK_Q: COPY_STRUCT( current_keyboard, tatituteto_keyboard);break;
	case OSDK_U: COPY_STRUCT( current_keyboard, naninuneno_keyboard);break;
	case OSDK_F: COPY_STRUCT( current_keyboard, hahihuheho_keyboard);break;
	case OSDK_J: COPY_STRUCT( current_keyboard, mamimumemo_keyboard);break;
	case OSDK_7 :COPY_STRUCT( current_keyboard, yayuyo_keyboard);break;
	case OSDK_O: COPY_STRUCT( current_keyboard, rarirurero_keyboard); break;
	case OSDK_0: COPY_STRUCT( current_keyboard, wawon_keyboard);break;
	default: break;
	}
}
 */

// **************************************************
//    touches Began
//
// **************************************************
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	NSLog(@"keyboard: touchesBegan ");
	NSUInteger numTouches=0;
	NSUInteger tapcount=0;
	CGPoint currentPoint;
	CGFloat px=0,py=0;
	NSTimeInterval timestampBegan_;
	int i=0;

	first_osdkeycode[0]=first_osdkeycode[1]=0;
	numTouches = [touches count];  // 指の数
	
	for( UITouch *touch in touches) {
		tapcount = [touch tapCount];//タッチした回数。同じポイントをタッチし続けると増える。
		currentPoint = [touch locationInView:self]; //タッチしたポイントの情報を取得。
		px = currentPoint.x; //タッチしたポイントのx座標。
		py = currentPoint.y; //タッチしたポイントのy座標。 
		timestampBegan_ = event.timestamp;	// タッチした時間
		
		NSLog(@"keyboard: touchesBegan [#%d] %3d,%3d tap=%d num=%d",i, (int)px,(int)py ,tapcount ,numTouches);
		
		if( tapcount ==2 && py < 200-30)		// double tap --> menu		/* かなキーボードを考慮 */
		{
			NSLog(@"keyboard: touchesBegan  (p6screen touched)\n");
			
			//ビューから代表クラスのポインターを得て、メッセージを送る
			// 参照：http://kontonsoft.blog.shinobi.jp/Entry/35/ 
			iP6_PlusAppDelegate *appDelegate = (iP6_PlusAppDelegate *)[[UIApplication sharedApplication]delegate];
			[appDelegate setToggleNavigatorBar];
			
		}
		else {
			start_x = px; start_y = py;			// screen flick's start xy 
		}

		int osdkeycode = check_button( px ,py);
		if( osdkeycode )
			{
				first_osdkeycode[i] = osdkeycode;	// first keycode if starting drag...
				dragfirstPoint = currentPoint;
				
				touch_flag = 1;					// touching ..
				touch_osdkeycode = osdkeycode;	// the keycode for actions

				if( keyboard_type == IPHONE_KANA_KEYBOARD )
					{
					if( osdkeycode==OSDK_3 || osdkeycode==OSDK_T || osdkeycode==OSDK_X || osdkeycode==OSDK_Q
					  ||osdkeycode==OSDK_U || osdkeycode==OSDK_F || osdkeycode==OSDK_J || osdkeycode==OSDK_7
					  ||osdkeycode==OSDK_O || osdkeycode==OSDK_0 || osdkeycode==OSDK_KUTOUTEN)
						{
							isFlikKeyboard =1;
							PUSH_STRUCT( current_keyboard);
						}
					switch( osdkeycode)
						{
							case OSDK_3: COPY_STRUCT( current_keyboard, aiueo_keyboard);break;
							case OSDK_T: COPY_STRUCT( current_keyboard, kakikukeko_keyboard);break;
							case OSDK_X: COPY_STRUCT( current_keyboard, sasisuseso_keyboard);break;
							case OSDK_Q: COPY_STRUCT( current_keyboard, tatituteto_keyboard);break;
							case OSDK_U: COPY_STRUCT( current_keyboard, naninuneno_keyboard);break;
							case OSDK_F: COPY_STRUCT( current_keyboard, hahihuheho_keyboard);break;
							case OSDK_J: COPY_STRUCT( current_keyboard, mamimumemo_keyboard);break;
							case OSDK_7 :COPY_STRUCT( current_keyboard, yayuyo_keyboard);break;
							case OSDK_O: COPY_STRUCT( current_keyboard, rarirurero_keyboard); break;
							case OSDK_0: COPY_STRUCT( current_keyboard, wawon_keyboard);break;
							case OSDK_KUTOUTEN: COPY_STRUCT( current_keyboard, kutouten_keyboard);break;
						default: break;
						}
 
					}
				else if( keyboard_type == IPHONE_GAME_KEYBOARD)
					{
					int keydown=1;
					keyboard_set_stick( osdkeycode ,keydown);

					NSLog(@"game keyboard:start keyrepeat \n");
					if( keyRepeatTimer==nil )
						keyRepeatTimer = [[NSTimer scheduledTimerWithTimeInterval:(1.0f) 
																		   target:self
																		 selector:@selector(KeyRepeatFunc) 
																		 userInfo:nil 
																		  repeats:YES] retain];
					 }
				
				[self setNeedsDisplay];			// update screen
			}
		//break;
	}
	
}

// **************************************************
//    touches Moved
//
// **************************************************
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
//	NSLog(@"keyboard: touchesMoved ");
	NSUInteger numTouches=0;
	NSUInteger tapcount=0;
	CGPoint currentPoint;
	CGFloat px=0,py=0;
	
	numTouches = [touches count];  // 指の数

    int i=0;
	for( UITouch *touch in touches) {
		tapcount = [touch tapCount];//タッチした回数。同じポイントをタッチし続けると増える。
		currentPoint = [touch locationInView:self]; //タッチしたポイントの情報を取得。
		px = currentPoint.x; //タッチしたポイントのx座標。
		py = currentPoint.y; //タッチしたポイントのy座標。 
		NSLog(@"keyboard: touchesMoved  %3d,%3d tap=%d num=%d",(int)px,(int)py ,tapcount ,numTouches);
				
				
		int osdkeycode = check_button( px ,py);
		if( osdkeycode )
			{
            if( first_osdkeycode[i] != osdkeycode)	// 最初に触ったキーコードから変化していたら、keyup する
                {
                int keydown =0;
                keyboard_set_stick( first_osdkeycode[i],keydown);
                first_osdkeycode[i] =osdkeycode;
                
                }

			touch_flag = 1;
			touch_osdkeycode = osdkeycode;			// the keycode for actions
				
			int keydown=1;
			keyboard_set_stick( osdkeycode ,keydown);
				
			[self setNeedsDisplay];
			}
		
		break;
		}
	
}

// **************************************************
//    touches Ended
//
// **************************************************
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	//NSUInteger numTouches = [touches count]; //画面にタッチしている指の数を取得。
	NSUInteger numTouches=0;
	NSUInteger tapcount=0;
	CGPoint currentPoint;
	CGFloat px=0,py=0;
	
	for( UITouch *touch in touches) {
		tapcount = [touch tapCount];//タッチした回数。同じポイントをタッチし続けると増える。
		currentPoint = [touch locationInView:self]; //タッチしたポイントの情報を取得。
		px = currentPoint.x; //タッチしたポイントのx座標。
		py = currentPoint.y; //タッチしたポイントのy座標。 
		NSLog(@"keyboard: touchesEnded  %3d,%3d tap=%d num=%d",(int)px,(int)py ,tapcount ,numTouches);
		
		[self setNeedsDisplay];
		break;
	}

	touch_flag = 0;
	touch_osdkeycode = 0;
	keyevent_execute(px, py); 

	if( isFlikKeyboard)				// kana keyboard
	{
		isFlikKeyboard = 0;
		POP_STRUCT( current_keyboard);
	}
	
	int keydown=0;
	keyboard_set_stick( first_osdkeycode[0] ,keydown);
	keyboard_set_stick( first_osdkeycode[1] ,keydown);

    if( keyRepeatTimer !=nil )
		{
		[keyRepeatTimer  invalidate];
		[keyRepeatTimer  release];
		keyRepeatTimer  =nil;
		first_osdkeycode[0]=first_osdkeycode[1]=0;
			
		{	/* カーソル全てのキーをはなしたことにする。。（おしっぱなしになるので） */
		int osdkeycode ,keydown=0;
		osdkeycode = OSDK_UP;    keyboard_set_stick( osdkeycode ,keydown);
		osdkeycode = OSDK_DOWN;  keyboard_set_stick( osdkeycode ,keydown);
		osdkeycode = OSDK_LEFT;  keyboard_set_stick( osdkeycode ,keydown);
		osdkeycode = OSDK_RIGHT; keyboard_set_stick( osdkeycode ,keydown);
		}
		NSLog(@"game keyboard: end keyrepeat");
		}


}



@end

//
//  viewcontroller.m
//  iP6_Plus
//
//  Created by うぃんでぃ on 09/12/05.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "iP6_PlusAppDelegate.h"
#import "viewcontroller.h"
#import "keyboard_view.h"

#import "../../src/iphone/iOSkey.h"
#import "../../src/P6.h"
#import "../../src/mem.h"
#import "../../src/keys.h"
//#import "../../src/mac/mackey.h"
#import "../../src/buffer.h"


@interface viewcontroller ()

@property (nonatomic) NSArray *commands;

@end

@implementation viewcontroller


keyboard_view *_keyboard_view;
view *_p6view;




// *****************************************************
//      can First Responder
// *****************************************************
- (BOOL)canBecomeFirstResponder
{
    return YES;
}


- (NSArray *)keyCommands
{
    return self.commands;
}

// *****************************************************
//      handle short cut keys
// *****************************************************
- (void)handleCommand:(UIKeyCommand *)command
{
    NSLog(@"handle short cut keys ");
    int scancode = 0;
    int osdkeycode =0;
    int modifierKey = 0;

    //[NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(hideHUD) object:nil];
    //[self displayHUD];
    //[self performSelector:@selector(hideHUD) withObject:nil afterDelay:1.0];
    
    UIKeyModifierFlags modifierFlags = command.modifierFlags;
    NSString *input = command.input;

    
    
    NSMutableString *modifierSymbols = [[NSMutableString alloc] init];
    NSMutableString *inputCharacters = [[NSMutableString alloc] init];
    
    if ((modifierFlags & UIKeyModifierAlphaShift) == UIKeyModifierAlphaShift) {
        [modifierSymbols appendString:@"⇪"];
    }
    if ((modifierFlags & UIKeyModifierShift) == UIKeyModifierShift) {
        [modifierSymbols appendString:@"SHIFT"];
        modifierKey |= MASK_SHIFT;
    }
    if ((modifierFlags & UIKeyModifierControl) == UIKeyModifierControl) {
        [modifierSymbols appendString:@"CTRL"];
        modifierKey |= MASK_CONTROL;
    }
    if ((modifierFlags & UIKeyModifierAlternate) == UIKeyModifierAlternate) {
        [modifierSymbols appendString:@"⌥"];
        modifierKey |= MASK_ALT;
    }
    if ((modifierFlags & UIKeyModifierCommand) == UIKeyModifierCommand) {
        [modifierSymbols appendString:@"⌘"];
        modifierKey |= MASK_CMD;
    }
    
    if ([input isEqualToString:@"\b"]) {
        [inputCharacters appendFormat:@"%@", @"DEL"];
        scancode = IOSK_BACKSPACE;
    }
    else if ([input isEqualToString:@"\t"]) {
        [inputCharacters appendFormat:@"%@", @"TAB"];
        scancode = IOSK_TAB;
    }
    else if ([input isEqualToString:@"\r"]) {
        [inputCharacters appendFormat:@"%@", @"ENTER"];
        scancode = IOSK_RETURN;
    }
    else if (input == UIKeyInputUpArrow) {
        [inputCharacters appendFormat:@"%@", @"↑"];
        scancode = IOSK_UP;
    }
    else if (input == UIKeyInputDownArrow) {
        [inputCharacters appendFormat:@"%@", @"↓"];
        scancode = IOSK_DOWN;
    }
    else if (input == UIKeyInputLeftArrow) {
        [inputCharacters appendFormat:@"%@", @"←"];
        scancode = IOSK_LEFT;
    }
    else if (input == UIKeyInputRightArrow) {
        [inputCharacters appendFormat:@"%@", @"→"];
        scancode = IOSK_RIGHT;
    }
    else if (input == UIKeyInputEscape) {
        [inputCharacters appendFormat:@"%@", @"ESC"];
        scancode = IOSK_ESCAPE;
    }
    else {
        char buff[100];
        strcpy( buff ,[input UTF8String]);
    
        printf("%02X \n",buff[0]);
        scancode = buff[0];
    }
    
    NSLog(@"%@", inputCharacters);
    
    
    // ------- function key --------
    if( (modifierKey & MASK_CMD) == MASK_CMD)
        {
        if( scancode >= IOSK_1 && scancode <= IOSK_5)
            {
            scancode = IOSK_F1 + scancode -IOSK_1;
            }
        }
    
    osdkeycode = OSD_transkey( scancode );
    
    // ------- control key ----------
    if( (modifierKey & MASK_CONTROL) == MASK_CONTROL)
        {
        write_keybuffer( keybuffer, 0x10, 1,     scancode , OSDK_LCTRL );
        }
    if( (modifierKey & MASK_SHIFT) == MASK_SHIFT)
        {
        write_keybuffer( keybuffer, 0x10, 1,     scancode , OSDK_LSHIFT );
        }

    
    write_keybuffer( keybuffer, 0x10, 1,     scancode , osdkeycode ); // key down
    write_keybuffer( keybuffer, 0x10, 0,     scancode , osdkeycode ); // key up

    if( (modifierKey & MASK_CONTROL) == MASK_CONTROL)
        {
        write_keybuffer( keybuffer, 0x10, 0,     scancode , OSDK_LCTRL );
        }
    if( (modifierKey & MASK_ALT) == MASK_ALT)
        {
        write_keybuffer( keybuffer, 0x10, 0,     scancode , OSDK_LCTRL );
        }
    if( (modifierKey & MASK_SHIFT) == MASK_SHIFT)
        {
        write_keybuffer( keybuffer, 0x10, 0,     scancode , OSDK_LSHIFT );
        }
    
}


/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

int fullScreen_=1;

// Implement loadView to create a view hierarchy programmatically, without using a nib.
//UIViewControllerクラスのviewプロパティが必要とされたタイミングにviewが無指定だった場合
//（initWithNibNameでxibファイルを指定していなかった場合、または viewコール前にsetViewしていなかった場合）、
//フレームワークによって自動的に呼ばれるメソッド（＝自分で直接呼んだらダメ）。
//ビュー作成にIBを使わず、マニュアルで作りたい場合にはここで作る
// *****************************************************
//
// *****************************************************
- (void)loadView {
	_keyboard_view = [[keyboard_view alloc ]initWithFrame: [[UIScreen mainScreen] bounds]];
	_keyboard_view.multipleTouchEnabled = YES;	// マルチタッチ有効
	_keyboard_view.userInteractionEnabled = YES;
	_keyboard_view.exclusiveTouch = NO;
	
	_p6view= [[view alloc]initWithFrame:[[UIScreen mainScreen] bounds]];

	self.view = _keyboard_view;
}


-(void)setKeyboardHidden:(BOOL)yes {
	if( yes )
		{
		self.view = _p6view;
		}
	else {
		self.view = _keyboard_view;
	}

			
}


// *****************************************************
//
// *****************************************************
-(void)goMenu:(id)sender {
	NSLog(@"goMenu \n");
	
	iP6_PlusAppDelegate *appDelegate = (iP6_PlusAppDelegate *)[[UIApplication sharedApplication]delegate];
	[appDelegate openMenu];
}

// *****************************************************
//
// *****************************************************
-(void)goClose:(id)sender {
	NSLog(@"goClose \n");
	[self.navigationController popViewControllerAnimated:YES];
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
// initWithNibName: bundle:でxibファイルが開かれたら、まず呼ばれるメソッド。画像等はまだ画面上に表示されていない
// *****************************************************
//
// *****************************************************
- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"viewDidLoad ");

    NSMutableArray *commands = [[NSMutableArray alloc] init];
    NSString *characters = @"`1234567890-=qwertyuiop[]asdfghjkl;'zxcvbnm,./_ ";
    for (NSInteger i = 0; i < characters.length; i++) {
        NSString *input = [characters substringWithRange:NSMakeRange(i, 1)];
        
        /* Caps Lock */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierAlphaShift action:@selector(handleCommand:)]];
        /* Shift */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierShift action:@selector(handleCommand:)]];
        /* Control */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierControl action:@selector(handleCommand:)]];
        /* Option */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierAlternate action:@selector(handleCommand:)]];
        /* Command */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierCommand action:@selector(handleCommand:)]];
        /* Control + Option */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierControl | UIKeyModifierAlternate action:@selector(handleCommand:)]];
        /* Control + Command */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierControl | UIKeyModifierCommand action:@selector(handleCommand:)]];
        /* Option + Command */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierAlternate | UIKeyModifierCommand action:@selector(handleCommand:)]];
        /* Control + Option + Command */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:UIKeyModifierControl | UIKeyModifierAlternate | UIKeyModifierCommand action:@selector(handleCommand:)]];
        /* No modifier */
        [commands addObject:[UIKeyCommand keyCommandWithInput:input modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    }
    /* Delete */
    [commands addObject:[UIKeyCommand keyCommandWithInput:@"\b" modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    /* Tab */
    [commands addObject:[UIKeyCommand keyCommandWithInput:@"\t" modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    /* Enter */
    [commands addObject:[UIKeyCommand keyCommandWithInput:@"\r" modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    
    /* Up */
    [commands addObject:[UIKeyCommand keyCommandWithInput:UIKeyInputUpArrow modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    /* Down */
    [commands addObject:[UIKeyCommand keyCommandWithInput:UIKeyInputDownArrow modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    /* Left */
    [commands addObject:[UIKeyCommand keyCommandWithInput:UIKeyInputLeftArrow modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    /* Right */
    [commands addObject:[UIKeyCommand keyCommandWithInput:UIKeyInputRightArrow modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    /* Esc */
    [commands addObject:[UIKeyCommand keyCommandWithInput:UIKeyInputEscape modifierFlags:kNilOptions action:@selector(handleCommand:)]];
    
    self.commands = commands.copy;


    // ************ UIBarButton **************
	UIBarButtonItem * menu_button = [[UIBarButtonItem alloc] initWithTitle:@"Menu"
										style: UIBarButtonItemStyleBordered 
										target:self 
										action:@selector(goMenu:)];

	/*UIBarButtonItem * close_button = [[UIBarButtonItem alloc] initWithTitle:@"Close" 
										style: UIBarButtonItemStyleBordered 
										target:self 
										action:@selector(goClose:)]; */
	
	//self.navigationItem.leftBarButtonItem = close_button;
	self.navigationItem.rightBarButtonItem = menu_button;
	self.navigationItem.title = @"iP6 Plus";	// ナビゲーションのタイトル
	//[close_button release];
	[menu_button release];
}

// *****************************************************
//
// *****************************************************
- (void)touchesEnded:(NSSet*)touches withEvent:(UIEvent*)event {
	NSLog(@"** touchesEnded \n");
	fullScreen_ = !fullScreen_;
	
	BOOL needAnimation = YES;
	
	if ( needAnimation ) {
		[UIView beginAnimations:nil context:NULL];
		[UIView setAnimationDuration:0.3];
	} 
	
//	[[UIApplication sharedApplication] setStatusBarHidden:fullScreen_ animated:needAnimation];
	self.navigationController.navigationBar.alpha = fullScreen_ ? 0.0 : 1.0;
	self.navigationController.toolbar.alpha = fullScreen_ ? 0.0 : 1.0;
	
	if ( needAnimation ) {
		[UIView commitAnimations];
	}
}

// *****************************************************
//
// *****************************************************
#if 0
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	//return (interfaceOrientation == UIInterfaceOrientationPortrait);
	return YES;
}
#endif

// *****************************************************
//      Autoratate OK       iOS 6.0 Later
// *****************************************************
-(BOOL)shouldAutorotate {
    return YES;
}



/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/
// *****************************************************
//
// *****************************************************
- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

// *****************************************************
//
// *****************************************************
- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

// *****************************************************
//
// *****************************************************
- (void)dealloc {
    [super dealloc];
}


@end

//
//  SampleForCustomizedCell.h
//
//  Created by ToKoRo on 2009-09-24.
//

#import <UIKit/UIKit.h>

@interface ConfigController : UITableViewController
{
 @private
  NSArray* sections_;
  NSArray* dataSource_;
}


@end

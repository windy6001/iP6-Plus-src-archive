//
//  setting.m
//  iP6_Plus
//
//  Created by うぃんでぃ on 10/04/01.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "setting.h"
#import "../../src/P6.h"

@implementation setting
/*
-(void)dealloc {
	[items_ release];
	[super  dealloc];
	
	CPURunning = 1;
}

-(id)init {
	if(( self = [super initWithStyle:UITableViewStylePlain])) {
		self.title= @"設定";
		
		//items_ = [[NSMutableArray alloc] initWithObjects: @"ViewController1", nil];
		
		CPURunning =0;
	}
	return self;
}

// *****************************************************
//
// *****************************************************
-(void)viewDidLoad {
	[super viewDidLoad];
	
	sections_ = [[NSArray alloc] initWithObjects: @"機種", @"", @"", nil ];
	NSArray *rows1 = [NSArray   arrayWithObjects: @"PC-6001",@"PC-6001mkII",@"PC-6601",@"PC-6001mkII",@"PC-6601SR", nil ];
	
	dataSource_ = [[NSArray alloc] initWithObjects:rows1,nil];
}	


//-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
//	return [items_ count];
//}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return [sections_ count ];
}

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section {
	return [[dataSource_ objectAtIndex:section] count ];
}

-(UITableViewCell*)tableView:(UITableView*)tableView cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
#if 0
	static NSString * identifier = @"basis-cell";
	//既にセルの型が登録済みかどうかをチェック
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
	if( !cell)		//セルの型が登録済みでなければ新しく登録する
	{
		cell = [[UITableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier:identifier];
		[cell autorelease];
	}
	// セルのラベルに表示するテキストを設定
	cell.textLabel.text = [[dataSource_ objectAtIndex:indexPath.section] objectAtIndex: indexPath.row];
	switch( indexPath.section)
	{
		case 0: [cell.contentView addSubview: [ self imageViewForCell: cell withFileName: @ "PC66SR.bmp"]];
			break;
		case 1: [cell.contentView addSubview: [ self switchForCell : cell]];
			break;
		case 2: [cell.contentView addSubview: [ self sliderForCell: cell]];
			break;
	}
	return cell;
#endif
}

// ********************** セルがタップされたときに呼ばれる　**********************
// indexPath で、どの行がタップされたか分かる。
-(void)tableView:(UITableView*)tableViewdidSelectRowAtIndexPath:(NSIndexPath*)indexPath
{
	Class class = NSClassFromString( [items_ objectAtIndex: indexPath.row]);
	id  viewController = [[[class alloc]init ] autorelease];
	if( viewController) {
		[self.navigationController pushViewController: viewController animated:YES];
	}
}
*/
@end

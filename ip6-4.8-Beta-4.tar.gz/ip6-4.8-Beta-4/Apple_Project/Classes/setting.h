//
//  setting.h
//  iP6_Plus
//
//  Created by うぃんでぃ on 10/03/18.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>


@interface setting : UITableViewController {
@private
	NSMutableArray * items_;
	NSArray * sections_;
	NSArray * dataSource_;
}

@end

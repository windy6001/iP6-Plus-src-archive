//
//  ESRenderer.h
//  test10
//
//  Created by うぃんでぃ on 10/03/08.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//
#ifdef USE_OPENGL
#import <QuartzCore/QuartzCore.h>

#import <OpenGLES/EAGL.h>
#import <OpenGLES/EAGLDrawable.h>

@protocol ESRenderer <NSObject>

- (void) render;
- (BOOL) resizeFromLayer:(CAEAGLLayer *)layer;

@end
#endif


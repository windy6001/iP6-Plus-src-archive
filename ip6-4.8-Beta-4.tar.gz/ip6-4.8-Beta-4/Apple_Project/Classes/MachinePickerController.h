//
//  MachinePickerController.h
//  iP6_Plus
//
//  Created by うぃんでぃ on 10/05/15.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface MachinePickerController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {


}
-(void)setMachineType: (int)inp;

@end

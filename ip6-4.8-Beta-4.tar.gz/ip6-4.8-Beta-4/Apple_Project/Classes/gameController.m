//
//  gameController.m
//  iP6_Plus
//
//  Created by うぃんでぃ on 2016/06/05.
//
//

#import "gameController.h"

@implementation gameController

-(void) GCControllerDidConnectNotification
{
    NSLog(@" connect");
}

-(void) GCControllerDidDisconnectNotification
{
    NSLog(@" disconnect");
}

@end


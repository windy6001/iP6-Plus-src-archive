//
//  view.m
//  iP6 Plus
//
//  Created by うぃんでぃ on 09/11/14.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//
#define USE_QUARTZ

#import "view.h"
#import "TopmenuController.h"

#import "../../src/Video.h"
#import "../../src/Refresh.h"
//#import "setting.h"



@implementation view

@synthesize zoom_rate;



// **************************************************
//    init
//
// **************************************************
- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
	
	self.backgroundColor = [UIColor clearColor];
    return self;
}



// **************************************************
//    drawRect :  UIView
//
// **************************************************
- (void)drawRect:(CGRect)rect {
#ifndef USE_OPENGL
    // Drawing code
	//CGContextRef save_context;
	//CGContextSaveGState( save_context);
	//printf("drawRect:%d %d %d %d ", rect.origin.x , rect.origin.y , rect.size.width ,rect.size.height );
	
	// get surface
	CGContextRef dst_cgcontext = UIGraphicsGetCurrentContext();
	OSD_Surface *src_surface = getRefreshSurface();
	CGContextRef src_cgcontext = src_surface->context;
	CGImageRef   src_image = CGBitmapContextCreateImage( src_cgcontext);

	// transform up side down 
	CGAffineTransform a_tr = CGAffineTransformIdentity;
	a_tr.d = -1.0f;
	a_tr.ty = 200;
	CGContextConcatCTM( dst_cgcontext , a_tr);

	
	// draw to window
	CGContextDrawImage( dst_cgcontext , CGRectMake(0,0,320,200) , src_image);

	//CGContextRestoreGState( save_context);
	
	// release image
	CGImageRelease( src_image);
#endif
}


- (void)dealloc {
    [super dealloc];
}

// **************************************************
//    touches began			(emulator window)
//
// **************************************************
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
	
	NSUInteger numTouches = [touches count]; //画面にタッチしている指の数を取得。
	NSUInteger tapcount=0;
	CGPoint currentPoint;
	CGFloat px=0,py=0;
	
	for( UITouch *touch in touches) {
		tapcount = [touch tapCount];//タッチした回数。同じポイントをタッチし続けると増える。
		currentPoint = [touch locationInView:self]; //タッチしたポイントの情報を取得。
		py = currentPoint.x; //タッチしたポイントのx座標。
		px = currentPoint.y; //タッチしたポイントのy座標。 
        NSLog(@"p6view: touchesBegan  %d,%d tap=%lu touch=%ld",(int)px,(int)py ,(unsigned long)tapcount ,numTouches);
		break;
	}
	if(tapcount==2)	
	{
		NSLog(@"tap count 2\n");
		
		// メニューを表示する
	//	topmenu *topmenu_ = [[[topmenu alloc]init]autorelease];
	//	UINavigationController  *rootController_ = [[UINavigationController alloc] initWithRootViewController: 
	//												topmenu_];
	//	[self addSubview:rootController_.view];

		
		//setting set = [setting alloc];
		
	}
	
}

// **************************************************
//    touches Moved			(emulator window)
//
// **************************************************
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
//	NSLog(@"p6view: touchesMoved ");
	
}

// **************************************************
//    touches ended			(emulator window)
//
// **************************************************
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
	NSLog(@"p6view: touchesEnded ");
}
@end



#if 0		// no transform
// transfrom rotate
a_tr = CGAffineTransformMakeRotation(M_PI * 270 / 180.0f);
//a_tr = CGAffineTransformTranslate(a_tr, (int)-130, (int)120);
a_tr = CGAffineTransformTranslate(a_tr, (int)-130*zoom_rate, (int)120-(200*zoom_rate-200));

CGContextConcatCTM( dst_cgcontext , a_tr);

a_tr = CGAffineTransformMakeScale(zoom_rate, zoom_rate);	// zoom_rate
CGContextConcatCTM( dst_cgcontext , a_tr);
#endif

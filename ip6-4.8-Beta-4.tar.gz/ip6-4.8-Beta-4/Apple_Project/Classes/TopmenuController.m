//
//  TopmenuController.m
//  iP6_Plus
//
//  Created by うぃんでぃ on 10/04/01.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//
#import "TopmenuController.h"
#import "iP6_PlusAppDelegate.h"
#import "ConfigController.h"
#import "OpenTapeController.h"
#import "OpenDiskController.h"
#import "OpenExtRomController.h"
#import "../../src/P6.h"
#import "../../src/mem.h"
#import "../../src/Option.h"

@implementation TopmenuController

enum {A_RESET};		// アラートの識別し

static int alert_type;		// アラートの種類

#pragma mark UIViewController methods

enum {M_CONFIG, M_RESETCPU ,M_OPENTAPE,M_REWINDTAPE, M_OPENDISK, M_CLOSEDISK, M_OPENEXTROM, M_CLOSEEXTROM, M_DUMMY,  M_GETROMS ,M_TEST};		//メニューアイテム　識別し



- (void)viewDidLoad {
	[super viewDidLoad];

	
	self.title = @"MENU";				// メニュー
	if ( !items_ ) {					// メニューアイテム
		items_ = [[NSArray alloc] initWithObjects:
				  @"Config",
				  @"Reset",
				  @"Open Tape",
				  @"Rewind Tape",
				  @"Open Disk",
				  @"Close Disk",
				  @"Open Ext Rom",
				  @"Close Ext Rom",
				  @"",
				  @"",
				  @"test",
				  nil ];
	} 
}

// *****************************************************
//			View が隠れたとき
// *****************************************************
- (void)viewDidDisappear:(BOOL)animated {
	[super viewDidDisappear:animated];
	CPURunning =1;			// resume Z80 CPU
	
//	iP6_PlusAppDelegate *appDelegate = (iP6_PlusAppDelegate *)[[UIApplication sharedApplication]delegate]; // ナビゲーション隠す
//	[appDelegate setToggleNavigatorBar];
}	

// *****************************************************
//			View が現れたとき
// *****************************************************

- (void)viewWillAppear:(BOOL)animated {
	CPURunning =0;			// stop Z80 CPU

	[super viewWillAppear:animated];
	
	[self.navigationController setNavigationBarHidden:NO animated:NO];
	//[self.navigationController setToolbarHidden:NO animated:NO];
	
	// バーの色を元に戻しておく
	/*[UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
	self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
	self.navigationController.navigationBar.translucent = NO;
	self.navigationController.toolbar.barStyle = UIBarStyleDefault;
	self.navigationController.toolbar.translucent = NO;
	*/
	
	[UIView setAnimationsEnabled:YES];
	

}

#pragma mark UITableView methods

// *****************************************************
//			メニューアイテムの数を返す
// *****************************************************
- (NSInteger)tableView:(UITableView*)tableView
 numberOfRowsInSection:(NSInteger)section
{
	return [items_ count];
}

// *****************************************************
//			
// *****************************************************
- (UITableViewCell*)tableView:(UITableView*)tableView
		cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	
	NSString* title = [items_ objectAtIndex:indexPath.row];
	cell.textLabel.text = [title stringByReplacingOccurrencesOfString:@"SampleFor" withString:@""];
	
	return cell;
}


// *****************************************************
//			アラートのボタンが押された
// *****************************************************
-(void)alertView: (UIAlertView*) alertView clickedButtonAtIndex:(NSInteger) buttonIndex {
	NSLog(@"alert push button \n");
	/* ------- リセット --------- */
	if( buttonIndex != alertView.cancelButtonIndex) {
		if( alert_type ==A_RESET)
			{
			CPURunning =1;
			ResetPC(0);		// RESET CPU
		
			[self.navigationController popViewControllerAnimated:YES];	// メニューを閉じる
		
			iP6_PlusAppDelegate *appDelegate = (iP6_PlusAppDelegate *)[[UIApplication sharedApplication]delegate]; // ナビゲーション隠す
			[appDelegate setToggleNavigatorBar];
			}
	}
}

// *****************************************************
//			Z80 CPUのリセット　　　　　　　アラートだして、はいなら、リセット処理する
// *****************************************************
-(void)resetCPU {
	alert_type = A_RESET;
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"　確認　"
													message:@"リセットしても良いですか？"
												   delegate:self
										  cancelButtonTitle:nil
						                  otherButtonTitles:@"いいえ", @"はい", nil]; 
	
	alert.cancelButtonIndex = 0;
	[alert show];
	[alert release];
	 
}


// *****************************************************
//			ROMファイルのダウンロード
// *****************************************************
-(void)readRoms:(NSString*)urlPath
{
/*	NSLog(@"readRoms: download start \n");
	DownloadRoms *downloadroms = [[DownloadRoms alloc] init];
	[downloadroms download: urlPath];
	[downloadroms release];
	NSLog(@"readRoms: download end \n");


	
	NSString *homedirectory = NSHomeDirectory();
	NSString *path = [ homedirectory stringByAppendingPathComponent: @"iP6 Plus.app/aaa.zip"];
	NSLog(@"unzip input path ='%@'\n",path);

	UnzipRoms *unziproms = [[UnzipRoms alloc]init];
	[unziproms unzip: path];
	[unziproms release];
 */
//	[homedirectory release];
//	[path release];
	
	
//	Network *net = [[Network alloc] init];
//	[net start: @"http://www.eonet.ne.jp/~windy/pc6001/ip6plus/P6-4.7.zip" filepath: @""];
//	[net release];
}


// *****************************************************
//			メニューアイテムが選択された
// *****************************************************
- (void)tableView:(UITableView*)tableView
didSelectRowAtIndexPath:(NSIndexPath*)indexPath
{
	if( indexPath.row == M_RESETCPU)
		{
		[self resetCPU];
		}
	else if( indexPath.row == M_CONFIG)
		{
		ConfigController *viewController = [[[ConfigController alloc]init] autorelease];
		[self.navigationController pushViewController:viewController animated:YES]; 
		newP6Version = P6Version;
		}
	else if( indexPath.row == M_OPENTAPE)
		{
		OpenTapeController *viewController = [[[OpenTapeController alloc]init] autorelease];
		[self.navigationController pushViewController:viewController animated:YES]; 
		}
	else if( indexPath.row == M_REWINDTAPE)
		{
		NSString *message;
		if( CasName[0][0]==0)
			{
			OpenFile1( FILE_LOAD_TAPE);
			message = @"テープを巻き戻しました";
			}
		else {
			message = @"テープは入ってません。";
		}
			
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"　情報　"
														message:message
													   delegate:self
											  cancelButtonTitle:nil
											  otherButtonTitles:@"OK", nil]; 
		alert.cancelButtonIndex = 0;
		[alert show];
		[alert release];
		}
	else if( indexPath.row == M_OPENDISK)
		{
		OpenDiskController *viewController = [[[OpenDiskController alloc]init] autorelease];
		[self.navigationController pushViewController:viewController animated:YES]; 
		}
	else if( indexPath.row == M_CLOSEDISK)
		{
		NSString *message;
		if(DskName[0][0] !=0)
			{
			DskName[0][0]=0;
			ConfigWrite();
			OpenFile1( FILE_DISK1);
			message = @"ディスクを取り除きました";
			}
		else {
			message = @"ディスクは入ってません。";
            }

				
#if 1
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"　情報　"
														message:message
													   delegate:self
											  cancelButtonTitle:nil
											  otherButtonTitles:@"OK", nil]; 
			
		alert.cancelButtonIndex = 0;
		[alert show];
		[alert release];
#endif
        
		}
	else if( indexPath.row == M_OPENEXTROM)
		{
		OpenExtRomController *viewController = [[[OpenExtRomController alloc]init] autorelease];
		[self.navigationController pushViewController:viewController animated:YES]; 
		}
	else if( indexPath.row == M_CLOSEEXTROM)
		{
		NSString *message;
		if(Ext1Name[0] !=0)
			{
			Ext1Name[0]=0;
			ConfigWrite();
			ResetPC(1);
			message = @"拡張ROMを取り除きました";
			}
		else {
			message = @"拡張ROMは入ってません。";
			}
		
		
		
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"　情報　"
														message:message
													   delegate:self
											  cancelButtonTitle:nil
											  otherButtonTitles:@"OK", nil]; 
		
		alert.cancelButtonIndex = 0;
		[alert show];
		[alert release];
		}
	
#if 0
	else if( indexPath.row == M_GETROMS)
		{
		DownloadController *viewController = [[[DownloadController alloc]init] autorelease];
		[self.navigationController pushViewController:viewController animated:YES];
		}
#endif
}
	/*		 NSString* className = [items_ objectAtIndex:indexPath.row];
	 Class class = NSClassFromString( className );
	 UIViewController* viewController = [[[class alloc] init] autorelease];
	 if ( !viewController ) {
	 NSLog( @"%@ was not found.", className );
	 return;
	 } 
	 [self.navigationController pushViewController:viewController animated:YES]; */
	
	
@end

//
//  view.h
//  iP6 Plus
//
//  Created by うぃんでぃ on 09/11/14.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface view : UIView {
	float zoom_rate;
}

- (BOOL)isZoomed;

@property (readwrite) IBOutlet float zoom_rate;

@end

//
//  iP6_PlusAppDelegate.h
//  iP6 Plus
//
//  Created by うぃんでぃ on 09/11/14.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GameController/GameController.h>

#import "view.h"
#import "keyboard_view.h"
#import "viewcontroller.h"

#ifdef USE_OPENGL
@class EAGLView;
#endif

@interface iP6_PlusAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	view *p6view;
	keyboard_view *p6keyboard_view;
    
#ifdef USE_OPENGL
    EAGLView *glView;
#endif
	viewcontroller *keyboard_viewcontroller;
	UINavigationController *naviController;
}
- (void)setToggleNavigatorBar;
- (void)KeyRepeatFunc ;

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet view *p6view;
@property (nonatomic, retain) IBOutlet keyboard_view *p6keyboard_view;
@property (nonatomic, retain) IBOutlet EAGLView *glView;

@property (nonatomic, retain) IBOutlet UINavigationController *naviController;
@property (nonatomic, retain) UILabel *myLabel;

@property (nonatomic) GCGamepad *gamepad;

@end

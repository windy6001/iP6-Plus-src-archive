

# iP6 Plus    (PC-6000/6600 Emulator)  

Last Update 2019/9/2

Release 4.8 Beta 4

## 1. はじめに

  このプログラムは、NEC PC-6000/6600 シリーズをエミュレートするプログラムです。
  
  isioさんの PC-6000/6600 シリーズのエミュレータである 「 iP6 for Unix/X11」をベースとして、
  SR特有の機能や、ディスク入出力機能等を　新たに追加しました。


## 2. 起動方法

### Windows 

バイナリーファイルの中の、iP6.exe をダブルクリックしてください。
ROMファイルが見つからない場合、「実行に必要なROMファイルを検索して、自動設定しますか？」と聞かれるので、はいと答えると、ディスクの中を検索します。ROMファイルが見つかると、「ROMファイルが見つかりました。」と表示されて、OKを押すとエミュレータが起動します。


### Unix/X11

- X11を、起動してください。
- ターミナルから、下記のコマンドで起動できます。

    $ ./iP6 


>　主なオプションについて
>
>    -60 .... PC-6001として起動する
>
>    -62 .... PC-6001mkII として起動する
>
>    -64 .... PC-6001mkIISR として起動する
>
>    -66 .... PC-6601 として起動する
>
>    -68 .... PC-6601SR として起動する


> -tape hoge.p6    hoge.p6 をテープイメージとしてマウントする
>
> -disk hoge.d88  hoge.d88 をディスクイメージとしてマウントする

## 3. できること 

オリジナルの iP6 for Unix/X11 に、いくつかのSR特有の機能とディスク入出力機能　などを追加します。

 - PC-6001/PC-6001mk2/PC-6601/PC-6001mk2SR/PC-6601SRの、それぞれの機種として動作可能。
- PC-Unix ネイティブと Windows ネイディブでの動作をサポート
- デバッグ機能をサポート
- テープの高速読み書き機能をサポート。
- ディスク入出力機能をサポート（2ドライブ対応)
- SR特有の機能を　サポート
- FM音源をサポート　（fmgen を使用。）
- 拡張漢字ROMと、拡張RAM(64kb) をサポート。
- 戦士のカートリッジ Ver.1 をサポート


## 4. 使い方


### 4.1 注意してほしいこと

このプログラムを使用されるときは、十分注意してご使用ください。
ROMイメージなど　大切なものに関しては、
**必ずバックアップをとっておいてください。**
　
　Rel.4.7 で、ディスクのアクセスランプを右下に作りました。(Windows版)
　<strong>これが点灯中は　ディスクにアクセスに行ってますので、いきなり終了したり、
　リセットしたりしないで下さい。</strong>


  <strong>ディスクやテープにアクセス中は、どこでもセーブしないでください。どこでもロードした場合、正しい動作を期待できない場合があり、最悪の場合、ディスクイメージなどの破損につながります。</strong>

　
　Rel.4.5 以降のバージョンから、d88のファイルが、読み取り専用になっている
　イメージも対応するようになりました。
　ただし、読み込みは出来ますが、書き込みは出来ませんので、注意が必要です。

　
　ゲームでディスクにセーブしたい場合などは、必ず　<strong>読み書き可能な属性にしてからマウントしてください。</strong>
　BASIC上で、save"hoge"や、bsave"hoge"としても、??AT Error となってしまいます。
　なお、d88ファイル内部のヘッダの書込み禁止フラグは見ていません。
　
　

　
### 4.2 必要なROM
　
　<p>実行するには、実機に内蔵されているROMファイルが必要になります。まずは、ROMを取得してください。
　
　<p>実行ファイルと同じディレクトリか、rom というサブディレクトリに置いてください。
　
　<p>
　<table border>
　<caption>(PC-6001 として利用する場合)</caption>
　<tr><th>ファイル名 </th><th>サイズ </th> <th>対応するROM</th></tr>
　<tr><td>BASICROM.60</td><td> 16KB</td> <td>N60-BASICインタプリタROM</td></tr>
　<tr><td>CGROM60.60 </td><td>  4KB</td> <td>N60-BASIC用CGROM        </td></tr>
　</table>
　<br>


　
　<table border>
　<caption>(PC-6001mk2 として利用する場合)</caption>
　<tr><th>ファイル名 </th><th>サイズ  </th> <th>対応するROM    </th></tr>
　<tr><td>BASICROM.62</td><td> 32KB </td> <td>N60m-BASICインタプリタROM</td></tr>
　<tr><td>CGROM60.62 </td><td>  8KB </td> <td>N60-BASIC用CGROM</td></tr>
　<tr><td>CGROM60m.62</td><td>  8KB </td> <td>N60m-BASIC用CGROM</td></tr>
　<tr><td>KANJIROM.62</td><td> 32KB </td> <td>漢字ROM        </td></tr>
　<tr><td>VOICEROM.62</td><td> 16KB </td> <td>音声合成ROM    </td></tr>
　</table>
　<br>
　
　<table border>
　<caption>(PC-6601 として利用する場合)</caption>
　<tr><th>ファイル名 </th><th>サイズ  </th> <th>対応するROM     </th></tr>
　<tr><td>BASICROM.66</td><td> 32KB </td> <td>N66-BASICインタプリタROM </td></tr>
　<tr><td>CGROM60.66 </td><td>  8KB </td> <td>N60-BASIC用CGROM</td></tr>
　<tr><td>CGROM66.66 </td><td>  8KB </td> <td>N66-BASIC用CGROM</td></tr>
　<tr><td>KANJIROM.66</td><td> 32KB </td> <td>漢字ROM         </td></tr>
　<tr><td>VOICEROM.66</td><td> 16KB </td> <td>音声合成ROM     </td></tr>
　</table>
　<br>
　
　<table border>
　<caption>(PC-6001mk2SR として利用する場合)</caption>
　<tr><th>ファイル名    </th><th>サイズ</th><th> 対応するROM  </th></tr>
　<tr><td>SYSTEMROM1.64 </td><td>64KB </td><td> システムROM1 </td></tr>
　<tr><td>SYSTEMROM2.64 </td><td>64KB </td><td> システムROM2 </td></tr>
　<tr><td>CGROM68.64    </td><td>16KB </td><td> CGROM (saver3で取り込んだROM)</td></tr>
　</table>
　<br>
　
　<table border>
　<caption>(PC-6601SR として利用する場合)</caption>
　<tr><th>ファイル名    </th><th>サイズ</th><th> 対応するROM  </th></tr>
　<tr><td>SYSTEMROM1.68 </td><td> 64KB </td><td> システムROM1 </td></tr>
　<tr><td>SYSTEMROM2.68 </td><td> 64KB </td><td> システムROM2 </td></tr>
　<tr><td>CGROM68.68    </td><td> 16KB </td><td> CGROM (saver3で取り込んだROM) </td></tr>
　</table>
　<br>
　
　オプション機能
　<table border>
　<caption>(拡張漢字ROM (PC-6006SR/ PC-6007SR) を、利用する場合)</caption>
　<tr><th>ファイル名    </th><th>サイズ</th><th> 対応するROM  </th></tr>
　<tr><td>EXTKANJI.ROM  </td><td>128KB </td><td> 拡張漢字ROM 　　　　　　　　　 </td></tr>
　</table>
　
　<p>拡張漢字ROMをお持ちの方は、ksaver で取り込んだ後、上記のファイル名にしてください。
　
　
　<hr>
　<h2>ROMの取得方法</h2>
　
　<p>基本的には、iP6 のROMを使いまわしできるのですが、SRをお持ちの方は、拙作の <a href="http://www.kisweb.ne.jp/personal/windy/computer/pc6001/p6soft.html">saver3</a> での吸出しをお勧めします。
　<p>(PC-6601SR の場合です。PC-6001mk2SRの方は、拡張子を.64にして下さい）
　
　<pre>
　1. MODE 6で起動して、拙作のsaver3 で次のROMを取得して下さい。
　
　SYSTEMROM1-1 を取得して、ファイル名を仮に SYSROM11にする。
　SYSTEMROM1-2 を取得して、ファイル名を仮に SYSROM12にする。
　SYSTEMROM2-1 を取得して、ファイル名を仮に SYSROM21にする。
　SYSTEMROM2-2 を取得して、ファイル名を仮に SYSROM22にする。
　CGROM　を取得して、　　　ファイル名を CGROM68.68 にする。
　
　2. SYSTEMROM が それぞれ別々に鳴っているので、下記のようにして結合してください。
　
　　　DOSなら、
　　　copy /b  SYSROM11+SYSROM12   SYSTEMROM1.68
　　　copy /b  SYSROM21+SYSROM22   SYSTEMROM2.68
　　　
　　　Unixなら、
　　　cat SYSROM11 SYSROM12  > SYSTEMROM1.68
　　　cat SYSROM21 SYSROM22  > SYSTEMROM2.68
　　　
　　　これでできあがりです。
　　　</pre>
　　　　<p>SR以外の方は、<a href="http://www.retropc.net/isio/">isioさんの saver </a>の使用をお勧めします。
　　　　
　　　　
　　　　<p>テープ経由の場合、最終的にテープ音声から、データに変換する必要があります。 
　　　　<a href="http://webclub.kcom.ne.jp/mb/morikawa/index.html">morikawa さんの　P6DatRec </a>の使用をお勧めします。
　　　　
　　　　<hr>
　　　　<h2>ディスクについて</h2>
　　　　
　　　　<p>今のところ、下記のような設定になっています。
　　　　
　　　　<table border>
　　　　<tr><th>機種        </th><th>ドライブ</th><th>使用可能なディスク </th></tr>
　　　　<tr><td>PC-6001mk2  </td><td>外付</td><td> 1D                 </td></tr>
　　　　<tr><td>PC-6001mk2SR</td><td>外付</td><td> 1DD/ 1D  自動認識  </td></tr>
　　　　<tr><td>PC-6601     </td><td>内蔵</td><td> 1D                 </td></tr>
　　　　<tr><td>PC-6601SR   </td><td>内蔵</td><td> 1DD　(1Dも一部可能)</td></tr>
　　　　</table>
　　　　
　　　　<p>mk2SRのみ、起動時に、1D/1DDを自動認識します。
　　　　PC-6601SRの場合、基本的に1DDですが、ディスクの先頭に　'SYS'が書かれていると、1Dと認識するようです。ただし、この時の1Dは、読み込みしか出来ません。
　　　　
　　　　<p>サポートしないディスクを指定した場合、ディスクを、自動的にイジェクト
　　　　してしまいます。ディスクなしになってしまうので、注意してください。
　　　　そのときは、メッセージで、お知らせします。
　　　　


### 4.3 Windows 版の起動の仕方

 
 - 実機からROMファイルを取り込んでください。
 - 実行ファイルと同じディレクトリか、ROMサブディレクトリに、上記のROMを置いてください。
 - iP6.exeを実行させると、まず、デフォルトでPC-6601SRとして起動しようとします。
- このときに、ROMファイルが見つからない場合は、その旨を表示します。
- PC-6601SR 以外として動作させたい場合は、Control メニューのConfigureの
  設定パネルで　ご希望の機種を選択してください。
　
  <p>設定のうち、(*)マークのついている分については、変更後、再起動するかどうか聞いてきますので今すぐ適用したい場合、再起動してください。
  設定は、ip6kai.iniファイルに書き込まれます。（実行ファイルと同じディレクトリーに　自動的にできます。）

  <p>詳しい使い方については、同梱のHELPファイルを参照してください。(＿)

　　　　


## 5. 開発者情報

### 5.1 ライセンス (license)


fMSXの派生物のため、Marat Fayzullin 様の fMSXのライセンスに準拠します。フリーウェアとしての使用が可能です。

Because it is a derivative of fMSX, it conforms to Mr.Marat Fayzullin's fMSX license. You can use it as freeware.


<br>
<br>


fmgen (PSG音源/FM音源エミュレーター) と、pd7752 (音声合成エミュレーター）は、cisc 様のライセンスに準拠します。 こちらも、フリーウェアとして使用が可能です。

fmgen (PSG / FM tone generator emulator) and pd7752 (speech synthesis emulator) comply with the license of Mr. cics. You can use only as freeware.


<br>
<br>


[重要] ソースリストを公開していますが、オープンソースではありません。商用利用は禁止とします。非商用の利用については自由にされてもいいですが、引用先を明記してください。
[Important] The source list is open, but it is not open source. Commercial use is prohibited. For non-commercial use, you can leave it freely, but please specify the quotation.
<br>
<br>


ソースリストのうち、schedule.c/schedule.h/Voice.c/Voice.h  はゆみたろ様のPC6001V 、西田様の Cocoa iP6 を参照しています。
Of the source list, schedule.c / schedule.h / Voice.c / Voice.h refers to Mr. Yumitaro's PC6001V and Mr. Nishida's Cocoa iP6.

### 5.2 ビルドの仕方

#### 5.2.1  Windows 

    - Windows 10を入れる
    - Visual Studio を入れる
    - [libpng](http://www.libpng.org/pub/png/libpng.html) [zlib](http://www.gzip.org/zlib/) のソースリストを落としてくる
    - libpng とzlib のスタティックライブラリ版( libpngd.lib , zlibd.lib ) をビルドする。
    - libpngd.lib と、zlibd.lib を、c:¥library¥lib にコピーしてください。　（デフォルトの場合）
    - Win_Project/iP6plus.vcxproj を開いて、ビルドしてください。
    
    

#### 5.2.2 Unix系OSでのコンパイルの仕方


     - OSと、X Window System を入れてください。
     - X11 ライブラリがない場合は、入れてください。
     - libpng と zlib とXaw と OpenAL のライブラリがない場合、入れてください。
     - 適当なディレクトリで、iP6 Plusのソースを展開してください。
     - ./configure   で、Makefileを生成してください
     - make   を実行してください
     - src ディレクトリの下の iP6 が実行ファイルです。


    注意：Mac 用のX11は、<a href="https://www.xquartz.org/"> XQuartz</a>を使ってください。
    　
<!--    
#### 5.2.2  iPhone    

    iPhone_Project/iP6_Plus.xcodeproj を開く
-->


### 5.3 fmgen の変更点

fmgen.cpp 343行目 void Operator::MakeTable() の中、処理系によっては、優先順位が変わるための対策をしました。

    *p++ = p[-512] / 2;
　　　　↓

    *p = p[-512] / 2;
    p++;
　　　　
file.cpp のWin32 依存部分を #ifdef WIN32 で囲いました。
opna.cpp と、opm.cppの、pow関数の呼び出し、pow(10,db / 40.0) となっているところを、pow(10.0 , db /40.0) というふうに変更しました。
　　　　
## 6. 既知の問題
　　　　
- 一部動かないゲームがあります。（ハドソン系はダメです)
- フロッピィドライブは　一部のコマンドしかサポートしていません。
- Unix環境で音が正しく鳴らないかもしれません。
- Unix環境では、設定ダイアログなどが、オリジナルの iP6 0.6.4 のままです。
- SRの音声合成機能は、ちゃんと喋れません。
- 動作がちょっと重いです。


## 7. 更新履歴


### Rel 4.8 β4の変更点 

- Windowsで、日本語環境以外の場合、なるべく英語表示するようにした（つもり）。
- Windowsの PAUSEメニューで、一時停止できるようにした

### Rel4.8 β3の変更点

- 漏れていたソースリストを追加した
- Unix/X11 環境でビルド出来なかった問題を修正（したはず） 


### Rel4.8 β2の変更点 

- デフォルト設定をスキャンライン無しにした
- デバッガーで、ダンプメモリーのときに、メモリーの内容を変更しようとすると、落ちていた問題を修正しました。


### Rel4.7以降の変更点 

- [Windows] PC-6601SRで、DATE$と、TIME$への書き込みが出来るようにしました。(起動時にOSの日時を取得して、それ以降、1秒ごとにタイマーを発火させて、1秒ずつ足していきます｡
- ブロック転送命令などの、必要CPUクロックが 0だったのを修正しました。（PC-6601SRの起動メニューの画面表示が速すぎる問題など解消しました）
- [Windows] 最大化できるようにしました
- [Windows] ウインドウの大きさを自由に変更可能に
- 起動時の RAMの初期状態をある程度再現しました。
- どこでも SAVE / LOAD 実装してみた。
- 未定義命令のサポートを追加しました。
- PC6001V のスケジュールを取り込みました。
- 音声合成機能を組み込んでみた。
- PC-6601SRの起動メニューから、テロッパを選ぶと、右下の表示がおかしくなる問題を修正しました。
- デバッグ機能を追加しました。
- デバッグ機能で、逆アセンブラリストをスクロール可能にしました。
- 本来入力できないキー（Shift＋￥）を、入力できないように修正しました。
- 本来入力できるはずのキー（かなの句読点）を入力できるように修正しました。
- ディスクを２ドライブ対応しました。

<!--
<p>Alpha-12

<li><del>ディスクを入れずに、PC-6601SR の起動メニューから、テロッパを選ぶとおかしくなる問題を修正しました。</del>
<ul>
<li>[X11]  gcc 4.x に対応するために、register 指定を取り除きました。
<li>[X11]  イベントのチェック方法を変更しました。
<li>[X11]  -wait をデフォルトで有効にしました。
<li>[Win]  イメージ作成ルーチンで、OSD_Surface を使うように変更しました。
<li>Keyboard()  を、共通ルーチンに移動しました。
<li>InitColor() を、共通ルーチンに移動しました。
<li>PutStatusbar() を、共通ルーチンに移動しました。
<li>オプション設定で、ROMのサーチパスを設定できるようにしました。
</ul>



<p>Alpha-5

<ul>
<li>[Win]  サウンドバッファの長さを 自動計算するようにしました。
<li>[Win]  ダイアログなどを表示している間、音源 (waveout) を一時停止するようにした
<li>
<li>
<li>キークリック音らしきものを再生？
<li>[Win]  DirectSound のドラ イバを書き中？
</ul>

<p>Alpha-4

<ul>
<li>[Win]  30fps で速度が1/2になっていた regression を修正しました。
<li>[Win]  fmgen のバージョンを、006 から008 に上げました。
<li>[Win]  CPUThreadFunc 関数を共通ルーチンへ移動
</ul>

<p>Alpha-3

<ul>
<li>[Win]  グラフィックの内部処理を 32ビットカラーから、8ビットカラーに変更
<li>[Win]  スナップショットのPNGファイルのガンマ値を低くして、ビューアーによる差異を解消
<li>[ALL]  Cocoa iP6 さんの音声合成処理を取り込み中...
<li>[X11]　Macで音が鳴るようになった。（Cocoa iP6 さんのプログラムを使用）
<li>[SDL]　一旦、SDLをソースツリーから外す。
<li>[ALL]　テープ読み込み失敗対策として、タイマー割り込みより、テープ割り込みを優先させてみる。
<li>[Win]  終了確認を、WM_CLOSE でするように変更。
<li>[Win]  60fpsに設定しても、常に 30fps になってしまっていたバグを修正
<li>[ALL]  SR以外の機種でも、FM音源を使えるように、FM音源カートリッジを挿入した状態に。
<li>[Win]  簡易デバッグ機能を使用可能に      (Cocoa iP6 さんのプログラムをベースに）

<li>[Win]  フレームスキップ処理を組み込む   
<li>[Win]  Sleep関数の精度を上げた
<li>[Win]  拡張ROMカートリッジを、メニューから開けるように  
</ul>

<p>Alpha-2
<ul>
<li>[ALL]  ソースリストをディレクトリーで分割
<li>[ALL]  音声合成のフォルマントデータを、ファイルに出力するようにしてみた。
<li>[Unix] autoconf / automake に対応　（まだまだ未熟ですが）
<li><del>[Win]  グラフィックの内部処理を 32ビットカラーから、8ビットカラーに変更</del>
<li>[Win]  スナップショットで出力されるファイルを、PNGフォーマットに対応。
<li><del>[SDL]  SDL版の画面の大きさのデフォルト設定を、1倍表示に変更</del>
<li><del>[SDL]  Za***s 向けのコンパイルが出来るようになった。</del>
<li>[Unix/SDL] 一度指定したオプションを覚えるように。
</ul>

<p>音声合成のフォルマントデータを、ファイルに出力するようにしました。
これにより、常に、testvoice.dat というファイルが作成されますが、これは暫定的な動作なので、
将来変更されるでしょう。
</p>
-->




<hr>
<h2>参考資料</h2>

<ul>
<li>PC-Techknow6000Vol.1
<li>PC-6001mk2取扱説明書
<li>Mr.PCテクニカルコレクション
<li>PC-6001/PC-6001MK2  わかるマシン語入門
<li>PC-9800 シリーズ テクニカルデータブック HARDWARE  編
<li>PC-9821 Undocument   ( http://www.webtech.co.jp/undoc/io_2d.txt )
</ul>

<hr>


<h2>免責事項</h2>

<p> ソースリストや、実行ファイルは基本的に無保証です。
テストは行っておりますが、
使用した結果、何らかの損害があったとしても、
当方では 一切感知できませんので、宜しくお願いします。

特に、大切なROMファイルなどは、必ずバックアップしたものを使用してください。



## 謝辞

 - iP6 for X11 を作られた 石岡さんに 感謝します。
 - fMSXの作者Marat Fayzullin さんに感謝します。
 - PC6001V の作者 ゆみたろさんに感謝します。
 - iP6win の作者 守谷さんに感謝します。
 - M88のDITTと、fmgen の作者のCISCさんに感謝します。
 - 1DDitt の作者の　bobsaito さんに感謝します。
 - アイコンの作者　天丸さんに感謝します。
 - PC6001VWの作者 Bernieさんに感謝します。
 - PC6001VXの作者 eighttails さんに感謝します。
 - バグをたくさん見つけてくれた、チョコぼんさんに、感謝します。
 - そして、このパソコンを作られた　日本電気の方々に感謝します。

<p>石岡さん本当にありがとうございました。(__)

<p>iP6 がなかったら、とてもじゃないけど、一からこれを作るのは、
無理だったと思いますので、感謝しても感謝しきれないです。（＿）




<hr>
<h2>お問い合わせ先</h2>


<p>なお、パッチやソースリストやプログラム自体に関する　お問い合わせについては、<big><a href="http://www.eonet.ne.jp/~windy/index.html">全て私までお願いします。</a></big>

<p>(isioさんは　このプログラムの開発に直接は関わってませんので、これについてisioさんに問い合わせることは、ご遠慮下さい。）

<P>バグや使用上の問題については、出来れば、対応したいと思っています。
しかし、フリーソフトウエアで有る以上、限界というものも有りますので、よろしくお願いします。


<!--
✴︎ Windows + Visual Studio 2017で、libpng と zlib のビルドのやり方
　
 - libpng と zlib のソースリストを展開する
 - libpng のあるディレクトリと同じ階層に zlib をディレクトリごとコピーする。
 - つまり、下記のような階層構造にする

    hoge_directory
            →libpng
            →zlib
           
 - libpng/projects/visualc71/libpng.vcprojを開く
 - メニューのすぐ下、 LIB Debug X86 となっているのを確認して、ビルドする
 - projects/Win32_LIB_Debug を開いて、libpngd.lib を見つける
 - projects/Win32_LIB_Debug/Zlib を開いて、zlibd.lib を見つける
-->


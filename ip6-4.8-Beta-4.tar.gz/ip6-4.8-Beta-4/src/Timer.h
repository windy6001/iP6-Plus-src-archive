void OSD_InitTimer(void);
void OSD_TrashTimer(void);
void OSD_Delay(int s);
dword OSD_GetTicks(void);

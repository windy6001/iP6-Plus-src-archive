// ******************************************************
//   Build.h       iP6 Plus build number
//            by Windy
// *******************************************************

#define PROGRAM_NAME "iP6 Plus "
#define BUILD_VER    "4.8 Beta-4"
#define BUILD_DATE   "Build 2019/09/03"

#define AUTHOR       "Modified by Windy"
#define HOMEPAGE_URL "http://www.eonet.ne.jp/~windy/"
#define HELP_FILE    "HELP-4.7.html"


